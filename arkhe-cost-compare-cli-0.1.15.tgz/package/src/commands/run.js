import { runDryRun } from "./dryRun.js";
import fs from "fs";
import path from "path";
import { resolveFromBase } from "../utils/paths.js";
import { buildGcslConfig } from "../engine/gcslBuilder.js";
import { runGcsimConfig } from "../engine/gcsimAdapter.js";
import { normalizeRotationInput } from "../engine/rotationAdapter.js";
import { computeERForTeam } from "../engine/erAdapter.js";
import { computeUtilVars } from "../engine/utilVarsAdapter.js";
import { writeResultsCsv } from "../output/csvWriter.js";
import { writeResultsJson } from "../output/jsonWriter.js";
import { mapWithConcurrency } from "../utils/parallel.js";
import { buildEnergySignature } from "../utils/energy.js";
import { buildRowTasks } from "../domain/taskPlanner.js";
import {
  resolveBackendRuntimePath,
  resolveGcsimExecutablePath,
  ensureExecutable,
} from "../utils/runtimePaths.js";

function toWeaponRefinementText(weaponRaw) {
  const raw = String(weaponRaw || "").toLowerCase();
  const refineMatch = raw.match(/^r(\d+)/i);
  const refine = refineMatch ? `R${refineMatch[1]}` : "R1";
  const name = raw.replace(/^r\d+/i, "");
  return `${name} ${refine}`.trim();
}

function normalizeId(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function buildCharacterStarsMap(backendRuntimePath) {
  try {
    const filePath = path.resolve(
      backendRuntimePath,
      "data",
      "characters.json",
    );
    const raw = fs.readFileSync(filePath, "utf8");
    const characters = JSON.parse(raw);
    const map = new Map();
    for (const entry of Array.isArray(characters) ? characters : []) {
      const key = normalizeId(entry?.character || entry?.name);
      if (!key) continue;
      map.set(key, Number(entry?.stars || 0));
    }
    return map;
  } catch {
    return new Map();
  }
}

function buildCharacterDataMap(backendRuntimePath) {
  try {
    const filePath = path.resolve(
      backendRuntimePath,
      "data",
      "characters.json",
    );
    const raw = fs.readFileSync(filePath, "utf8");
    const characters = JSON.parse(raw);
    const map = new Map();
    for (const entry of Array.isArray(characters) ? characters : []) {
      const key = normalizeId(entry?.character || entry?.name);
      if (!key) continue;
      map.set(key, {
        stars: Number(entry?.stars || 0),
        element: normalizeId(entry?.element),
        interestStat: normalizeId(entry?.interestStat).slice(0, 1),
      });
    }
    return map;
  } catch {
    return new Map();
  }
}

function formatMainStats(mainCodeRaw) {
  const mainCode = String(mainCodeRaw || "")
    .trim()
    .toLowerCase();
  if (mainCode.length < 3) return "Sands: - | Goblet: - | Circlet: -";

  const sandsMap = {
    a: "ATK%",
    h: "HP%",
    f: "DEF%",
    e: "EM",
    r: "ER%",
  };
  const gobletMap = {
    a: "ATK%",
    h: "HP%",
    f: "DEF%",
    e: "EM",
    d: "Elemental DMG",
  };
  const circletMap = {
    c: "CRIT",
    b: "Healing Bonus",
    a: "ATK%",
    h: "HP%",
    f: "DEF%",
    e: "EM",
    r: "ER%",
    d: "Elemental DMG",
  };

  const sands = sandsMap[mainCode[0]] || "ATK%";
  const goblet = gobletMap[mainCode[1]] || "ATK%";
  const circlet = circletMap[mainCode[2]] || "CRIT";

  return `Sands: ${sands} | Goblet: ${goblet} | Circlet: ${circlet}`;
}

function formatSetName(rawName) {
  const name = String(rawName || "")
    .trim()
    .toLowerCase();
  if (!name) return "";
  if (name.length <= 4) return name.toUpperCase();
  return `${name[0].toUpperCase()}${name.slice(1)}`;
}

function formatArtifactSet(setRaw) {
  const raw = String(setRaw || "")
    .trim()
    .toLowerCase();
  if (!raw) return "-";

  const parts = [];
  const regex = /(\d)([a-z0-9]+?)(?=\d|$)/g;
  let match;
  while ((match = regex.exec(raw)) !== null) {
    parts.push(`${match[1]}pc ${formatSetName(match[2])}`);
  }

  if (parts.length > 0) return parts.join(" ");
  return formatSetName(raw);
}

function computeCost(teamCombo, characterStarsMap) {
  return teamCombo.reduce((sum, member) => {
    const character = normalizeId(member?.character);
    const stars = Number(characterStarsMap?.get(character) || 0);
    const isFiveStarCharacter = stars === 5;
    const characterCost = isFiveStarCharacter
      ? 1 + Math.max(0, Number(member?.cons || 0))
      : 0;

    return sum + characterCost + (member.isFiveStarWeapon ? 1 : 0);
  }, 0);
}

function buildUtilVarsSignature(teamCombo) {
  return (teamCombo || [])
    .map((member) => {
      return [member.character, member.set]
        .map((value) =>
          String(value || "")
            .trim()
            .toLowerCase(),
        )
        .join(":");
    })
    .join("|");
}

function isFavoniusWeapon(weaponId) {
  const weapon = String(weaponId || "")
    .toLowerCase()
    .replace(/^r\d+/i, "");
  return weapon.includes("fav") && !weapon.includes("aquila");
}

function buildFavMaskBySlot(teamCombo) {
  const parts = [];
  for (let index = 0; index < (teamCombo || []).length; index += 1) {
    if (isFavoniusWeapon(teamCombo[index]?.weapon)) {
      parts.push(`slot${index + 1}`);
    }
  }
  return parts.length > 0 ? parts.join("|") : "none";
}

function buildTeamComboSignature(teamCombo) {
  return (teamCombo || [])
    .map((member) => {
      return [
        normalizeId(member?.character),
        Number(member?.cons || 0),
        normalizeId(member?.weapon),
        normalizeId(member?.set),
        normalizeId(member?.main),
        member?.gobletOptim ? "gobletOptim" : "noGobletOptim",
      ].join(":");
    })
    .join("|");
}

function buildMainCodeWithGoblet(mainCode, gobletCode) {
  const normalizedMainCode = String(mainCode || "")
    .trim()
    .toLowerCase();
  if (normalizedMainCode.length < 3) {
    return normalizedMainCode;
  }
  return `${normalizedMainCode[0]}${gobletCode}${normalizedMainCode[2]}`;
}

function buildGobletOptimizationVariants(teamCombo, characterDataMap) {
  const validGobletInterestStats = new Set(["a", "h", "f", "e"]);
  const optimizableMembers = (teamCombo || [])
    .map((member, index) => {
      if (!member?.gobletOptim) return null;
      const character = normalizeId(member?.character);
      const characterData = characterDataMap?.get(character);
      const interestGoblet = String(characterData?.interestStat || "")
        .trim()
        .toLowerCase()
        .slice(0, 1);
      const normalizedMain = normalizeId(member?.main);
      if (
        !character ||
        normalizedMain.length < 3 ||
        !validGobletInterestStats.has(interestGoblet)
      ) {
        return null;
      }
      return {
        index,
        character,
        interestGoblet,
      };
    })
    .filter(Boolean);

  if (optimizableMembers.length === 0) {
    return [{ teamCombo, summary: "" }];
  }

  let variants = [{ teamCombo, summary: "" }];
  for (const target of optimizableMembers) {
    const expandedVariants = [];
    for (const variant of variants) {
      for (const gobletCode of [target.interestGoblet, "d"]) {
        const updatedTeamCombo = variant.teamCombo.map(
          (member, memberIndex) => {
            if (memberIndex !== target.index) {
              return member;
            }
            return {
              ...member,
              main: buildMainCodeWithGoblet(member?.main, gobletCode),
            };
          },
        );
        expandedVariants.push({
          teamCombo: updatedTeamCombo,
          summary: `${variant.summary}${variant.summary ? ", " : ""}${target.character}:${gobletCode}`,
        });
      }
    }
    variants = expandedVariants;
  }

  const dedupedVariants = new Map();
  for (const variant of variants) {
    const signature = buildTeamComboSignature(variant.teamCombo);
    if (!dedupedVariants.has(signature)) {
      dedupedVariants.set(signature, variant);
    }
  }

  return Array.from(dedupedVariants.values());
}

async function loadTeamRotationContext({
  teamCombo,
  rotation,
  gcsimPath,
  backendRuntimePath,
  baseDir,
  tempDir,
  scenario,
  utilVarsCache,
  utilVarsByCase,
  erCache,
  erMapByCase,
  erDebugEnabled,
  erDebugPath,
}) {
  const energySignature = buildEnergySignature(teamCombo);
  const utilVarsSignature = buildUtilVarsSignature(teamCombo);
  const erCacheKey = `${rotation.id}|energy:${energySignature}`;
  const utilVarsCacheKey = `${rotation.id}|util:${utilVarsSignature}`;

  let utilVars = {
    scrollActivations: 0,
    cryoRes: 0,
    rotationDurationSeconds: 0,
  };

  if (!utilVarsCache.has(utilVarsCacheKey)) {
    utilVarsCache.set(
      utilVarsCacheKey,
      computeUtilVars({
        gcsimPath,
        backendRuntimePath,
        scenarioBaseDir: baseDir,
        teamCombo,
        rotationGcsl: rotation.gcslRotation,
        tempDir,
        keepTemp: scenario.output.keepTemp,
        timeoutMs: scenario.simulation.timeoutMs,
      }),
    );
  }
  utilVars = (await utilVarsCache.get(utilVarsCacheKey)) || utilVars;
  utilVarsByCase[utilVarsCacheKey] = utilVars;

  let additionalERByCharacter = {};
  if (scenario.simulation.enableER) {
    if (!erCache.has(erCacheKey)) {
      erCache.set(
        erCacheKey,
        computeERForTeam({
          gcsimPath,
          teamCombo,
          rotationGcsl: rotation.gcslRotation,
          backendRuntimePath,
          scenarioBaseDir: baseDir,
          erIterations: scenario.simulation.erIterations,
          erPercentile: scenario.simulation.erPercentile,
          tempDir,
          keepTemp: scenario.output.keepTemp,
          timeoutMs: scenario.simulation.timeoutMs,
          debug: {
            enabled: erDebugEnabled,
            filePath: erDebugPath,
            scenarioName: scenario.meta.name,
            rotationId: rotation.id,
            rotationLabel: rotation.label,
            energySignature,
            teamCombo,
          },
        }),
      );
    }
    additionalERByCharacter = (await erCache.get(erCacheKey)) || {};
    erMapByCase[erCacheKey] = additionalERByCharacter;
  }

  return {
    additionalERByCharacter,
    energySignature,
    erCacheKey,
    utilVars,
    utilVarsCacheKey,
  };
}

async function preOptimizeGoblets({
  combinations,
  firstRotation,
  parallel,
  gcsimPath,
  backendRuntimePath,
  baseDir,
  tempDir,
  scenario,
  characterDataMap,
  utilVarsCache,
  utilVarsByCase,
  erCache,
  erMapByCase,
  erDebugEnabled,
  erDebugPath,
}) {
  if (!firstRotation) {
    return combinations;
  }

  const targetableCombinations = combinations.filter((teamCombo) =>
    (teamCombo || []).some((member) => member?.gobletOptim),
  );
  if (targetableCombinations.length === 0) {
    return combinations;
  }

  const optimizedBySignature = new Map();
  const probeLiquidRolls = Number(scenario.selection?.liquidRolls?.[0] || 20);

  console.log(
    `[run] goblet pre-opt: ${targetableCombinations.length} team combos using first rotation and 10 iterations.`,
  );

  const optimizedCombinations = await mapWithConcurrency(
    combinations,
    parallel,
    async (teamCombo) => {
      const originalSignature = buildTeamComboSignature(teamCombo);
      if (optimizedBySignature.has(originalSignature)) {
        return optimizedBySignature.get(originalSignature);
      }

      const variants = buildGobletOptimizationVariants(
        teamCombo,
        characterDataMap,
      );
      if (variants.length <= 1) {
        optimizedBySignature.set(originalSignature, teamCombo);
        return teamCombo;
      }

      try {
        const { additionalERByCharacter, utilVars } =
          await loadTeamRotationContext({
            teamCombo,
            rotation: firstRotation,
            gcsimPath,
            backendRuntimePath,
            baseDir,
            tempDir,
            scenario,
            utilVarsCache,
            utilVarsByCase,
            erCache,
            erMapByCase,
            erDebugEnabled,
            erDebugPath,
          });

        let bestVariant = variants[0];
        let bestDps = Number.NEGATIVE_INFINITY;

        for (const variant of variants) {
          const builtConfig = await buildGcslConfig({
            teamCombo: variant.teamCombo,
            rotationInput: firstRotation.gcslRotation,
            iterations: 10,
            additionalERByCharacter,
            liquidRolls: probeLiquidRolls,
            maxRolls: scenario.selection.maxRolls,
            allowOvercapERRolls: scenario.selection.allowOvercapERRolls,
            backendRuntimePath,
            scenarioBaseDir: baseDir,
            scrollActivationsByCharacter: utilVars.scrollActivations,
            cryoRes: utilVars.cryoRes,
            forceCR100: true,
          });

          const metrics = await runGcsimConfig({
            gcsimPath,
            configText: String(builtConfig?.configText || "").trim(),
            timeoutMs: scenario.simulation.timeoutMs,
            tempDir,
            keepTemp: scenario.output.keepTemp,
            verbose: false,
          });

          if (Number(metrics?.dps || 0) > bestDps) {
            bestDps = Number(metrics?.dps || 0);
            bestVariant = variant;
          }
        }

        const optimizedTeamCombo = bestVariant.teamCombo;
        optimizedBySignature.set(originalSignature, optimizedTeamCombo);

        const optimizedSignature = buildTeamComboSignature(optimizedTeamCombo);
        if (optimizedSignature !== originalSignature) {
          console.log(`[run] goblet pre-opt selected: ${bestVariant.summary}`);
        } else {
          console.log(
            `[run] goblet pre-opt kept current mains: ${bestVariant.summary || "no-change"}`,
          );
        }

        return optimizedTeamCombo;
      } catch (err) {
        console.warn(
          `[run] goblet pre-opt skipped for team ${originalSignature}: ${err.message}`,
        );
        optimizedBySignature.set(originalSignature, teamCombo);
        return teamCombo;
      }
    },
  );

  return optimizedCombinations;
}

function buildResultRow({
  teamCombo,
  liquidRolls,
  aggregate,
  rotations,
  characterStarsMap,
  resolvedMainByCharacter,
}) {
  const members = teamCombo;
  const avgShares = aggregate.shareSums.map((value) => {
    return aggregate.shareCount > 0 ? (value / aggregate.shareCount) * 100 : 0;
  });

  const row = {
    char1: members[0]?.character || "-",
    char1Cons: `C${Number(members[0]?.cons || 0)}`,
    char1WeaponRefinement: toWeaponRefinementText(members[0]?.weapon),
    char1Set: formatArtifactSet(members[0]?.set),
    char1MainStats: formatMainStats(
      resolvedMainByCharacter?.[normalizeId(members[0]?.character)]
        ?.resolvedMainCode || members[0]?.main,
    ),
    char2: members[1]?.character || "-",
    char2Cons: `C${Number(members[1]?.cons || 0)}`,
    char2WeaponRefinement: toWeaponRefinementText(members[1]?.weapon),
    char2Set: formatArtifactSet(members[1]?.set),
    char2MainStats: formatMainStats(
      resolvedMainByCharacter?.[normalizeId(members[1]?.character)]
        ?.resolvedMainCode || members[1]?.main,
    ),
    char3: members[2]?.character || "-",
    char3Cons: `C${Number(members[2]?.cons || 0)}`,
    char3WeaponRefinement: toWeaponRefinementText(members[2]?.weapon),
    char3Set: formatArtifactSet(members[2]?.set),
    char3MainStats: formatMainStats(
      resolvedMainByCharacter?.[normalizeId(members[2]?.character)]
        ?.resolvedMainCode || members[2]?.main,
    ),
    char4: members[3]?.character || "-",
    char4Cons: `C${Number(members[3]?.cons || 0)}`,
    char4WeaponRefinement: toWeaponRefinementText(members[3]?.weapon),
    char4Set: formatArtifactSet(members[3]?.set),
    char4MainStats: formatMainStats(
      resolvedMainByCharacter?.[normalizeId(members[3]?.character)]
        ?.resolvedMainCode || members[3]?.main,
    ),
    cost: computeCost(members, characterStarsMap),
    liquidRolls,
    char1AvgPct: `${avgShares[0].toFixed(2)}%`,
    char2AvgPct: `${avgShares[1].toFixed(2)}%`,
    char3AvgPct: `${avgShares[2].toFixed(2)}%`,
    char4AvgPct: `${avgShares[3].toFixed(2)}%`,
    totalDPS: aggregate.weightedDps,
    duration: aggregate.averageDuration,
  };

  rotations.forEach((rotation, idx) => {
    const key = `damage_rot_${String(rotation.label || rotation.id || idx + 1)
      .replace(/\s+/g, "_")
      .toLowerCase()}`;
    row[key] = Number(aggregate.damageByRotation?.[rotation.id] || 0);
  });

  return row;
}

function sortRows(rows, sortBy = "weightedDps", sortDir = "desc") {
  const factor = String(sortDir || "desc").toLowerCase() === "asc" ? 1 : -1;
  const keyMap = {
    weighteddps: "totalDPS",
    totaldps: "totalDPS",
    cost: "cost",
    duration: "duration",
  };

  const resolvedKey =
    keyMap[String(sortBy || "weightedDps").toLowerCase()] || "totalDPS";

  return [...rows].sort((a, b) => {
    const av = Number(a?.[resolvedKey] || 0);
    const bv = Number(b?.[resolvedKey] || 0);
    if (av === bv) return 0;
    return av > bv ? factor : -factor;
  });
}

export async function runScenario(options = {}) {
  const result = await runDryRun(options);
  const { scenario, expanded, scenarioPath } = result;
  const baseDir = path.dirname(scenarioPath);

  const maxRuns = Number(options.maxRuns || 0);
  const totalRuns = expanded.counts.totalRuns;
  const runLimit =
    Number.isFinite(maxRuns) && maxRuns > 0 ? maxRuns : totalRuns;

  const gcsimPath = resolveGcsimExecutablePath({
    scenarioBaseDir: baseDir,
    gcsimPath: scenario.simulation.gcsimPath,
    cliOverridePath: options.gcsimPath,
  });
  ensureExecutable(gcsimPath);
  const backendRuntimePath = resolveBackendRuntimePath();
  const characterDataMap = buildCharacterDataMap(backendRuntimePath);
  const characterStarsMap = buildCharacterStarsMap(backendRuntimePath);
  const tempDir = resolveFromBase(baseDir, scenario.output.tempDir);
  const erDebugEnabled =
    scenario.simulation.erDebug ||
    ["1", "true", "yes"].includes(
      String(process.env.ARKHE_ER_DEBUG || "")
        .trim()
        .toLowerCase(),
    );
  const erDebugPath = resolveFromBase(
    baseDir,
    process.env.ARKHE_ER_DEBUG_FILE ||
      scenario.simulation.erDebugFile ||
      "./out/er-debug.jsonl",
  );

  if (erDebugEnabled) {
    console.log(`[run] ER debug enabled. log file: ${erDebugPath}`);
  }

  const normalizedRotations = [];
  for (const rotation of scenario.rotations) {
    const gcslRotation = await normalizeRotationInput({
      rotationInput: rotation.input,
      rots: scenario.simulation.rots,
      operation: "calc",
      backendRuntimePath,
      scenarioBaseDir: baseDir,
      verbose: scenario.simulation.gcsimVerbose,
    });
    if (!gcslRotation) {
      throw new Error(
        `Failed to normalize rotation ${rotation.label || rotation.id}`,
      );
    }
    normalizedRotations.push({
      ...rotation,
      gcslRotation,
    });
  }

  const failures = [];
  const erCache = new Map();
  const utilVarsCache = new Map();
  const erMapByCase = {};
  const utilVarsByCase = {};

  const parallel = Math.max(1, Number(scenario.simulation.parallel || 1));
  const plannedTaskPreview = buildRowTasks({
    teamCombinations: expanded.teamCombinations,
    liquidRolls: scenario.selection.liquidRolls,
    rotations: normalizedRotations,
    runLimit,
  });
  const executionCombinations = Array.from(
    new Map(
      plannedTaskPreview.tasks.map((task) => [
        buildTeamComboSignature(task.teamCombo),
        task.teamCombo,
      ]),
    ).values(),
  );
  const optimizedCombinations = await preOptimizeGoblets({
    combinations: executionCombinations,
    firstRotation: normalizedRotations[0],
    parallel,
    gcsimPath,
    backendRuntimePath,
    baseDir,
    tempDir,
    scenario,
    characterDataMap,
    utilVarsCache,
    utilVarsByCase,
    erCache,
    erMapByCase,
    erDebugEnabled,
    erDebugPath,
  });

  const combinations = optimizedCombinations;
  const rotsDivisor = Math.max(1, Number(scenario.simulation.rots || 1));
  const { tasks, scheduledRuns } = buildRowTasks({
    teamCombinations: combinations,
    liquidRolls: scenario.selection.liquidRolls,
    rotations: normalizedRotations,
    runLimit,
  });

  console.log(
    `[run] executing up to ${scheduledRuns} runs (of ${totalRuns} planned) with concurrency ${parallel}.`,
  );

  if (scenario.simulation.enableER) {
    const precomputeJobs = [];
    const seenErCases = new Set();

    for (const teamCombo of combinations) {
      const energySignature = buildEnergySignature(teamCombo);
      const favMask = buildFavMaskBySlot(teamCombo);

      for (const rotation of normalizedRotations) {
        const erCacheKey = `${rotation.id}|energy:${energySignature}`;
        if (erCache.has(erCacheKey)) continue;
        if (seenErCases.has(erCacheKey)) continue;
        seenErCases.add(erCacheKey);

        precomputeJobs.push({
          erCacheKey,
          rotation,
          teamCombo,
          energySignature,
          favMask,
        });
      }
    }

    console.log(
      `[run] ER precompute: ${precomputeJobs.length} unique cases across ${normalizedRotations.length} rotations.`,
    );

    const erCaseSummary = {};
    await mapWithConcurrency(precomputeJobs, parallel, async (job) => {
      const erMap = await computeERForTeam({
        gcsimPath,
        teamCombo: job.teamCombo,
        rotationGcsl: job.rotation.gcslRotation,
        backendRuntimePath,
        scenarioBaseDir: baseDir,
        erIterations: scenario.simulation.erIterations,
        erPercentile: scenario.simulation.erPercentile,
        tempDir,
        keepTemp: scenario.output.keepTemp,
        timeoutMs: scenario.simulation.timeoutMs,
        debug: {
          enabled: erDebugEnabled,
          filePath: erDebugPath,
          scenarioName: scenario.meta.name,
          rotationId: job.rotation.id,
          rotationLabel: job.rotation.label,
          energySignature: job.energySignature,
          teamCombo: job.teamCombo,
          favMask: job.favMask,
          mode: "precompute",
        },
      });

      erCache.set(job.erCacheKey, erMap || {});
      erMapByCase[job.erCacheKey] = erMap || {};

      if (!erCaseSummary[job.rotation.id]) {
        erCaseSummary[job.rotation.id] = {
          label: job.rotation.label,
          totalCases: 0,
          favCases: {},
        };
      }
      erCaseSummary[job.rotation.id].totalCases += 1;
      erCaseSummary[job.rotation.id].favCases[job.favMask] =
        (erCaseSummary[job.rotation.id].favCases[job.favMask] || 0) + 1;
    });

    console.log("[run] ER precompute completed.");

    if (erDebugEnabled) {
      try {
        const mapOutputPath = erDebugPath.replace(/\.jsonl$/i, "-map.json");
        fs.writeFileSync(
          mapOutputPath,
          JSON.stringify(
            {
              scenario: scenario.meta,
              erIterations: scenario.simulation.erIterations,
              erPercentile: scenario.simulation.erPercentile,
              totalCases: precomputeJobs.length,
              rotations: erCaseSummary,
            },
            null,
            2,
          ),
          "utf8",
        );
        console.log(`[run] ER case map: ${mapOutputPath}`);
      } catch (err) {
        console.warn(`[run] failed to write ER case map: ${err.message}`);
      }
    }
  }

  let progressCompleted = 0;

  const taskResults = await mapWithConcurrency(
    tasks,
    parallel,
    async (task) => {
      const { teamCombo, liquidRolls, rotations } = task;
      const aggregate = {
        damageByRotation: {},
        weightedDps: 0,
        durationSum: 0,
        durationCount: 0,
        shareSums: [0, 0, 0, 0],
        shareCount: 0,
        averageDuration: 0,
      };

      let hasSuccess = false;
      let resolvedMainByCharacter = {};

      for (const rotation of rotations) {
        try {
          const { additionalERByCharacter, utilVars } =
            await loadTeamRotationContext({
              teamCombo,
              rotation,
              gcsimPath,
              backendRuntimePath,
              baseDir,
              tempDir,
              scenario,
              utilVarsCache,
              utilVarsByCase,
              erCache,
              erMapByCase,
              erDebugEnabled,
              erDebugPath,
            });

          const builtConfig = await buildGcslConfig({
            teamCombo,
            rotationInput: rotation.gcslRotation,
            iterations: scenario.simulation.iterations,
            additionalERByCharacter,
            liquidRolls,
            maxRolls: scenario.selection.maxRolls,
            allowOvercapERRolls: scenario.selection.allowOvercapERRolls,
            backendRuntimePath,
            scenarioBaseDir: baseDir,
            scrollActivationsByCharacter: utilVars.scrollActivations,
            cryoRes: utilVars.cryoRes,
          });

          const cfg = String(
            builtConfig?.configText || builtConfig || "",
          ).trim();
          if (!cfg) {
            throw new Error("Failed to build GCSL config");
          }
          resolvedMainByCharacter = {
            ...(builtConfig?.resolvedMainByCharacter || {}),
          };

          const metrics = await runGcsimConfig({
            gcsimPath,
            configText: cfg,
            timeoutMs: scenario.simulation.timeoutMs,
            tempDir,
            keepTemp: scenario.output.keepTemp,
            verbose: scenario.simulation.gcsimVerbose,
          });

          hasSuccess = true;
          aggregate.damageByRotation[rotation.id] = metrics.dps;
          aggregate.weightedDps +=
            metrics.dps * (Number(rotation.weightPercent || 0) / 100);
          aggregate.durationSum +=
            Number(metrics.duration || utilVars.rotationDurationSeconds || 0) /
            rotsDivisor;
          aggregate.durationCount += 1;

          const totalCharacter = metrics.characterDps.reduce(
            (sum, value) => sum + Number(value || 0),
            0,
          );
          if (totalCharacter > 0) {
            for (let index = 0; index < 4; index += 1) {
              aggregate.shareSums[index] +=
                Number(metrics.characterDps[index] || 0) / totalCharacter;
            }
            aggregate.shareCount += 1;
          }
        } catch (err) {
          failures.push({
            team: teamCombo
              .map((member) => `${member.character}C${member.cons}`)
              .join(", "),
            liquidRolls,
            rotation: rotation.label,
            error: err.message,
          });
        }

        progressCompleted += 1;
        if (
          progressCompleted % Math.max(1, parallel) === 0 ||
          progressCompleted === scheduledRuns
        ) {
          console.log(`[run] progress: ${progressCompleted}/${scheduledRuns}`);
        }
      }

      if (!hasSuccess) {
        return null;
      }

      aggregate.averageDuration =
        aggregate.durationCount > 0
          ? aggregate.durationSum / aggregate.durationCount
          : 0;

      return buildResultRow({
        teamCombo,
        liquidRolls,
        aggregate,
        rotations: normalizedRotations,
        characterStarsMap,
        resolvedMainByCharacter,
      });
    },
  );

  const rows = taskResults.filter(Boolean);

  const sortedRows = sortRows(
    rows,
    scenario.output.sortBy,
    scenario.output.sortDir,
  );

  console.log("[run] utilVars results:");
  console.log(JSON.stringify(utilVarsByCase, null, 2));
  if (scenario.simulation.enableER) {
    console.log("[run] ER map results:");
    console.log(JSON.stringify(erMapByCase, null, 2));
  }

  const topN = Number(scenario.output.topN || 0);
  const finalRows = topN > 0 ? sortedRows.slice(0, topN) : sortedRows;

  const csvPath = writeResultsCsv({
    rows: finalRows,
    rotations: normalizedRotations,
    outputPath: scenario.output.csvPath,
    baseDir,
  });

  const jsonPath = writeResultsJson({
    payload: {
      meta: scenario.meta,
      executedRuns: scheduledRuns,
      plannedRuns: totalRuns,
      concurrency: parallel,
      normalizedRotations,
      utilVarsByCase,
      erMapByCase,
      rows: finalRows,
      failures,
    },
    outputPath: scenario.output.jsonPath,
    baseDir,
  });

  console.log(`[run] completed. executed runs: ${scheduledRuns}/${totalRuns}`);
  console.log(`[run] rows exported: ${finalRows.length}`);
  console.log(`[run] csv: ${csvPath}`);
  if (jsonPath) {
    console.log(`[run] json: ${jsonPath}`);
  }
  if (failures.length > 0) {
    console.log(
      `[run] failures: ${failures.length} (see json output for details)`,
    );
  }
}
