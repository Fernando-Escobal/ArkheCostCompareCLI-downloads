function normalizeId(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function ensureRefinedWeapon(value) {
  const raw = normalizeId(value);
  if (!raw) return "";
  if (/^r\d/.test(raw)) return raw;
  return `r1${raw}`;
}

function ensureFourPieceSet(value) {
  const raw = normalizeId(value);
  if (!raw) return "";
  return /^\d/.test(raw) ? raw : `4${raw}`;
}

function normalizeMain(value) {
  return normalizeId(value).replace(/\s+/g, "");
}

export function normalizeScenario(scenario) {
  return {
    ...scenario,
    rotations: (scenario.rotations || []).map((rotation, idx) => ({
      id: String(rotation.id || `r${idx + 1}`),
      label: String(rotation.label || `Rotation ${idx + 1}`),
      input: String(rotation.input || "").trim(),
      weightPercent: Number(rotation.weightPercent || 0),
    })),
    team: (scenario.team || []).map((member, idx) => ({
      slot: Number(member.slot || idx + 1),
      character: normalizeId(member.character),
      consOptions: Array.from(new Set(member.consOptions || [0])).sort(
        (a, b) => a - b,
      ),
      weapon4: ensureRefinedWeapon(member.weapon4),
      weapon5: ensureRefinedWeapon(member.weapon5),
      set: ensureFourPieceSet(member.set),
      main: normalizeMain(member.main),
    })),
    selection: {
      ...scenario.selection,
      liquidRolls: Array.from(
        new Set(scenario.selection?.liquidRolls || [20]),
      ).sort((a, b) => a - b),
      maxRolls: Math.max(
        15,
        Math.min(45, Number(scenario.selection?.maxRolls ?? 45) || 45),
      ),
    },
  };
}
