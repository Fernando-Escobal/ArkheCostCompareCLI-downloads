import fs from "fs";
import path from "path";
import { pathToFileURL } from "url";
import { resolveBackendRuntimePath } from "../utils/runtimePaths.js";

let backendBuilderModuleCache = null;
let charactersCache = new Map();

function normalizeId(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function isLikelyGcslRotation(text) {
  const raw = String(text || "").toLowerCase();
  return (
    raw.includes("for let i") ||
    raw.includes("active ") ||
    raw.includes(";\n") ||
    raw.includes(";")
  );
}

function normalizeRotationScript(rotationInput) {
  return String(rotationInput || "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function extractInitialActive(rotationInput) {
  const text = String(rotationInput || "").trim();
  const match = text.match(/^active\s+([a-z0-9_]+)\s*;/i);
  return match ? normalizeId(match[1]) : "";
}

function stripInlineActiveCommands(rotationInput) {
  return String(rotationInput || "")
    .replace(/^active\s+[a-z0-9_]+\s*;\s*/i, "")
    .replace(/\bactive\s+[a-z0-9_]+\s*;?/gi, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

async function loadBackendBuilderModule(backendRuntimePath) {
  if (backendBuilderModuleCache) return backendBuilderModuleCache;
  const modulePath = path.resolve(
    backendRuntimePath,
    "modules",
    "gcslBuilder.js",
  );
  backendBuilderModuleCache = await import(pathToFileURL(modulePath).href);
  return backendBuilderModuleCache;
}

function loadCharactersData(backendRuntimePath) {
  const cacheKey = path.resolve(backendRuntimePath);
  if (charactersCache.has(cacheKey)) {
    return charactersCache.get(cacheKey);
  }

  const charactersPath = path.resolve(
    backendRuntimePath,
    "data",
    "characters.json",
  );
  const raw = fs.readFileSync(charactersPath, "utf8");
  const parsed = JSON.parse(raw);
  charactersCache.set(cacheKey, parsed);
  return parsed;
}

function findCharacterData(charactersData, characterName) {
  const normalized = normalizeId(characterName);
  return (charactersData || []).find(
    (entry) =>
      normalizeId(entry?.character) === normalized ||
      normalizeId(entry?.name) === normalized,
  );
}

export async function buildGcslConfig({
  teamCombo,
  rotationInput,
  iterations = 100,
  additionalERByCharacter = {},
  liquidRolls = 20,
  maxRolls = 45,
  backendRuntimePath,
  scrollActivationsByCharacter = 0,
  cryoRes = 0,
  scenarioBaseDir,
}) {
  if (!isLikelyGcslRotation(rotationInput)) {
    throw new Error(
      "Rotation input is not in GCSL format yet. Provide a GCSL rotation script for local run.",
    );
  }

  const runtimeBackendPath = resolveBackendRuntimePath({
    scenarioBaseDir,
    backendRuntimePath,
  });

  const builderModule = await loadBackendBuilderModule(runtimeBackendPath);
  const buildCharacterGCSLWithMeta = builderModule?.buildCharacterGCSLWithMeta;
  if (typeof buildCharacterGCSLWithMeta !== "function") {
    throw new Error(
      "Could not load buildCharacterGCSLWithMeta from backend module",
    );
  }

  const dataPath = path.resolve(runtimeBackendPath, "data");
  const charactersData = loadCharactersData(runtimeBackendPath);

  const lines = [];
  const resolvedMainByCharacter = {};
  const firstCharacter =
    extractInitialActive(rotationInput) ||
    normalizeId(teamCombo?.[0]?.character);

  teamCombo.forEach((member) => {
    const character = normalizeId(member.character);
    const characterData = findCharacterData(charactersData, character);
    if (!characterData) {
      throw new Error(`Character data not found for ${character}`);
    }

    const additionalER = Number(additionalERByCharacter?.[character] || 0);
    const built = buildCharacterGCSLWithMeta(
      characterData,
      String(member.set || ""),
      String(member.weapon || ""),
      String(member.main || ""),
      Number.isFinite(additionalER) ? additionalER : 0,
      Number(scrollActivationsByCharacter || 0),
      Number(member.cons || 0),
      Number(cryoRes || 0),
      dataPath,
      Number(liquidRolls || 20),
      Number(maxRolls || 45),
    );

    resolvedMainByCharacter[character] = {
      resolvedMainCode: String(
        built?.resolvedMainCode || String(member.main || "").toLowerCase(),
      ),
      sandsForcedToER: Boolean(built?.sandsForcedToER),
      sandsSwitchedFromER: Boolean(built?.sandsSwitchedFromER),
    };

    lines.push(String(built?.gcsl || "").trim());
    lines.push("");
  });

  if (firstCharacter) {
    lines.push(`active ${firstCharacter};`);
    lines.push("");
  }

  lines.push("# Options");
  lines.push(`options swap_delay=12 iteration=${Number(iterations) || 100};`);
  lines.push("target lvl=100 resist=0.1 radius=2 pos=0,2.5 hp=999999999;");
  lines.push("energy every interval=480,720 amount=1;");
  lines.push("");
  lines.push("# Rotation");
  lines.push(stripInlineActiveCommands(normalizeRotationScript(rotationInput)));

  return {
    configText: lines.join("\n"),
    resolvedMainByCharacter,
  };
}
