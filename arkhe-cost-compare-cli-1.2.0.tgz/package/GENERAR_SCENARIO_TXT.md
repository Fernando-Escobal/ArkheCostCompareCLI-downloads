﻿# Generar scenario.txt

> Esta guia aplica a la version mas reciente de Arkhe Cost Compare CLI.

## Formato

```ini
[meta]
[simulation]
[rotations]
[team]
[selection]
[output]
```

## Ejemplo

```ini
[meta]
name=example_constellation_compare
version=1

[simulation]
iterations=100
rots=4
parallel=4
timeoutMs=120000
gcsimPath=
erIterations=350
erPercentile=0.8
enableER=false
substatOptim=false
gcsimVerbose=false

[rotations]
r1.label=rotation_a
r1.weight=50
r1.input=Nahida EQ > Xingqiu EQ > Yelan EQ > Kuki E

r2.label=rotation_b
r2.weight=50
r2.input=Yelan EQ > Nahida EQ > Xingqiu EQ > Kuki E

[team]
slot1.character=nahida
slot1.cons=0|2
slot1.weapon4=r5sacrificialfragments
slot1.weapon5=r1athousandfloatingdreams
slot1.set=4deepwood
slot1.main=edc

slot2.character=xingqiu
slot2.cons=6
slot2.weapon4=r5favoniussword
slot2.weapon5=
slot2.set=4emblem
slot2.main=adc

slot3.character=kuki
slot3.cons=0|2|4
slot3.weapon4=r5ironsting
slot3.weapon5=r1freedomsworn
slot3.set=4flowerofparadiselost
slot3.main=eec

slot4.character=yelan
slot4.cons=0|1
slot4.weapon4=r5favoniuswarbow
slot4.weapon5=r1elegyfortheend
slot4.set=4emblem
slot4.main=hdc
slot4.gobletOptim=true

[selection]
maxRolls=45
liquidRolls=20,22,24
requireWeight100=true

[output]
csv=./out/results.csv
json=./out/results.json
sortBy=weightedDps
sortDir=desc
topN=0
keepTemp=false
tempDir=./.tmp
```

## Reglas clave

- gcsimPath es opcional.
- Si gcsimPath esta vacio, se intenta ../gcsim con binario por plataforma.
- Los pesos de [rotations] deben sumar 100 cuando requireWeight100=true.
- El equipo debe tener exactamente slot1..slot4.
- slotN.weapon4 es obligatorio.
- slotN.gobletOptim es opcional. Si vale true, el CLI compara el goblet de interestStat vs Elemental DMG usando la primera rotacion y se queda con el mejor para ese team combo.
- maxRolls es opcional, por defecto 45, y debe estar entre 15 y 45.
- liquidRolls debe tener al menos un entero y cada valor debe estar entre 20 y maxRolls.

## Combos disponibles

- Constelaciones por slot:
  - Campo: slotN.cons
  - Formato: valores separados por |
  - Ejemplo: slot1.cons=0|2|6

- Armas por slot:
  - Se genera 1 opcion si solo hay weapon4.
  - Se generan 2 opciones si hay weapon4 y weapon5.
  - Ejemplo: slot4.weapon4=r5favoniuswarbow y slot4.weapon5=r1elegyfortheend

- Liquid rolls:
  - Campo: liquidRolls
  - Formato: enteros separados por coma
  - Rango valido por valor: 20..maxRolls
  - Ejemplo: liquidRolls=20,22,24

- Main stat code por slot:
  - Campo: slotN.main
  - Formato: 3 letras (sands, goblet, circlet)
  - Letras comunes: a (ATK%), h (HP%), f (DEF%), e (EM), r (ER), d (DMG%), c (Crit)
  - Perfiles con ajuste especifico de substats en el builder:
    - adc, edc, hdc, hhc, eee, eec, ree, hhh, rhh, ffc, fdc, ffb, ehc, aac, rdc
  - Cualquier otro codigo usa la regla default del builder.

- Pre-optimizacion de goblet:
  - Campo opcional: slotN.gobletOptim=true
  - Compara para ese personaje el goblet de interestStat vs d (Elemental DMG).
  - Se ejecuta una sola vez por team combo.
  - Usa solo la primera rotacion del scenario.
  - Fuerza CR al 100% en todo el equipo y usa 10 iteraciones para reducir ruido.
  - El ganador se reutiliza para todas las rotaciones y liquidRolls de esa combinacion.

- Formula de combinaciones totales por rotacion:
  - builds = producto(cons por slot) x producto(armas por slot) x cantidad(liquidRolls)
  - total runs = builds x cantidad(rotaciones)
