﻿# Preparar el entorno

## 1. Verificar Node

```powershell
node -v
```

Debes tener Node.js 18 o superior.

## 2. Ubicar gcsim

Opcion A: definir ruta en scenario.txt con gcsimPath.

Opcion B: dejar gcsimPath vacio y usar ruta relativa externa por defecto:

```text
Windows: ../gcsim/gcsim.exe
Linux: ../gcsim/gcsim
macOS: ../gcsim/gcsim
```

## 3. Validar herramientas

Desde la carpeta del proyecto:

```powershell
node .\\bin\\arkhe-cc.js doctor
```

## 4. Validar scenario

```powershell
node .\\bin\\arkhe-cc.js dry-run --scenario .\\example.scenario.txt
```

## 5. Smoke test

```powershell
node .\\bin\\arkhe-cc.js run --scenario .\\example.scenario.txt --maxRuns 2
```

Si estos tres comandos funcionan, el entorno esta listo.
