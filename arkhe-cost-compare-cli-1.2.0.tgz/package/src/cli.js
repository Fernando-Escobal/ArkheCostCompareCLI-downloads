import { parseArgs } from "./utils/args.js";
import { runDoctor } from "./commands/doctor.js";
import { runDryRun } from "./commands/dryRun.js";
import { runScenario } from "./commands/run.js";
import { runErDebug } from "./commands/erDebug.js";

function printHelp() {
  console.log("arkhe-cc <command> [options]");
  console.log("");
  console.log("Commands:");
  console.log(
    "  doctor                       Validate local toolchain (gcsim)",
  );
  console.log(
    "  dry-run --scenario <file>    Parse and validate scenario, estimate runs",
  );
  console.log(
    "  run --scenario <file>        Execute local simulation pipeline and export CSV",
  );
  console.log(
    "  er-debug --config <file>     Run gcsim -erNeeded for raw config and write trace logs",
  );
  console.log("");
  console.log("Options:");
  console.log("  --scenario <file>            Path to scenario txt file");
  console.log(
    "  --maxRuns <n>                Cap total executed runs (debug/smoke)",
  );
  console.log(
    "  scenario [simulation] supports: optional gcsimPath, enableER, erIterations, erPercentile, erDebug, erDebugFile",
  );
  console.log(
    "  --gcsimPath <file>           Override gcsim executable path (doctor)",
  );
  console.log(
    "  er-debug options: --config, --erIterations, --erPercentile, --out, --log, --timeoutMs",
  );
}

export async function runCli(argv) {
  const parsed = parseArgs(argv);
  const command = parsed._[0] || "help";

  if (["help", "-h", "--help"].includes(command)) {
    printHelp();
    return;
  }

  if (command === "doctor") {
    await runDoctor(parsed);
    return;
  }

  if (command === "dry-run") {
    await runDryRun(parsed);
    return;
  }

  if (command === "run") {
    await runScenario(parsed);
    return;
  }

  if (command === "er-debug") {
    await runErDebug(parsed);
    return;
  }

  throw new Error(`Unknown command: ${command}`);
}
