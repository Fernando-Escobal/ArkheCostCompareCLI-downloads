import { parseScenarioFile } from "../config/scenarioParser.js";
import { validateScenario } from "../config/scenarioValidator.js";
import { normalizeScenario } from "../domain/normalizeScenario.js";
import { expandCombinations } from "../domain/expandCombinations.js";
import { resolveFromCwd } from "../utils/paths.js";

export async function runDryRun(options = {}) {
  const scenarioPath = resolveFromCwd(
    options.scenario || "./example.scenario.txt",
  );
  const scenario = parseScenarioFile(scenarioPath);
  const normalized = normalizeScenario(scenario);
  const errors = validateScenario(normalized);

  if (errors.length > 0) {
    console.error("[dry-run] scenario validation failed:");
    errors.forEach((error) => console.error(`- ${error}`));
    throw new Error("Invalid scenario file");
  }

  const expanded = expandCombinations(normalized);
  const counts = expanded.counts;

  console.log("[dry-run] scenario loaded");
  console.log(`- name: ${normalized.meta.name || "(unnamed)"}`);
  console.log(`- rotations: ${counts.rotationCount}`);
  console.log(
    `- constellation combinations: ${counts.constellationCombinations}`,
  );
  console.log(`- weapon combinations: ${counts.weaponCombinations}`);
  console.log(`- team combinations: ${counts.teamCombinations}`);
  console.log(`- liquid rolls variants: ${counts.liquidRollVariants}`);
  console.log(`- total runs: ${counts.totalRuns}`);
  console.log(`- output csv: ${normalized.output.csvPath}`);

  return {
    scenarioPath,
    scenario: normalized,
    expanded,
  };
}
