import fs from "fs";
import path from "path";
import { runProcess } from "../utils/proc.js";
import {
  resolveGcsimExecutablePath,
  ensureExecutable,
} from "../utils/runtimePaths.js";
import { resolveFromBase } from "../utils/paths.js";

function appendLog(logPath, payload) {
  const dirPath = path.dirname(logPath);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
  fs.appendFileSync(
    logPath,
    `${JSON.stringify({ ts: new Date().toISOString(), ...payload })}\n`,
    "utf8",
  );
}

export async function runErDebug(options = {}) {
  const configArg = String(options.config || "").trim();
  if (!configArg) {
    throw new Error("Missing required argument: --config <gcsim-config-file>");
  }

  const configPath = path.resolve(process.cwd(), configArg);
  if (!fs.existsSync(configPath)) {
    throw new Error(`Config file not found: ${configPath}`);
  }

  const configBaseDir = path.dirname(configPath);
  const gcsimPath = resolveGcsimExecutablePath({
    scenarioBaseDir: configBaseDir,
    gcsimPath: options.gcsimPath,
    cliOverridePath: options.gcsimPath,
  });
  ensureExecutable(gcsimPath);

  const erIterations = Number(options.erIterations || 350);
  const erPercentile = Number(options.erPercentile || 0.8);
  const outPath = resolveFromBase(
    process.cwd(),
    String(options.out || "./out/er-debug-raw.json"),
  );
  const logPath = resolveFromBase(
    process.cwd(),
    String(options.log || "./out/er-debug-trace.jsonl"),
  );

  const args = [
    "-c",
    configPath,
    "-erNeeded",
    "-erIterations",
    String(Number.isFinite(erIterations) ? erIterations : 350),
    "-erPercentile",
    String(Number.isFinite(erPercentile) ? erPercentile : 0.8),
    "-out",
    outPath,
  ];

  appendLog(logPath, {
    phase: "er-debug:start",
    configPath,
    gcsimPath,
    erIterations,
    erPercentile,
    args,
  });

  const exec = await runProcess(gcsimPath, args, {
    timeoutMs: Number(options.timeoutMs || 180000),
  });

  appendLog(logPath, {
    phase: "er-debug:process-result",
    code: exec.code,
    stdout: exec.stdout,
    stderr: exec.stderr,
  });

  if (exec.code !== 0) {
    throw new Error(
      `gcsim ER debug failed with code ${exec.code}. stderr: ${exec.stderr || "(empty)"}`,
    );
  }

  if (!fs.existsSync(outPath)) {
    throw new Error(`gcsim did not generate ER output file: ${outPath}`);
  }

  const rawText = fs.readFileSync(outPath, "utf8");
  let parsed = [];
  try {
    parsed = JSON.parse(rawText);
  } catch {
    // keep parsed as [] and emit raw text
  }

  appendLog(logPath, {
    phase: "er-debug:output",
    outPath,
    entries: Array.isArray(parsed) ? parsed.length : 0,
    payload: parsed,
    rawText: Array.isArray(parsed) ? undefined : rawText,
  });

  console.log("[er-debug] completed");
  console.log(`[er-debug] gcsim: ${gcsimPath}`);
  console.log(`[er-debug] config: ${configPath}`);
  console.log(`[er-debug] erIterations: ${erIterations}`);
  console.log(`[er-debug] erPercentile: ${erPercentile}`);
  console.log(`[er-debug] output: ${outPath}`);
  console.log(`[er-debug] trace: ${logPath}`);

  if (Array.isArray(parsed) && parsed.length > 0) {
    console.log("[er-debug] additionalER summary:");
    parsed.forEach((entry) => {
      console.log(
        `- ${String(entry?.name || "?")}: additionalER=${Number(entry?.additionalER || 0).toFixed(4)}, recommendedERSubs=${Number(entry?.recommendedERSubs || 0)}`,
      );
    });
  }
}
