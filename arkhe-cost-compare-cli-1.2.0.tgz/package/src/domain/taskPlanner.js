export function buildRowTasks({
  teamCombinations = [],
  liquidRolls = [],
  rotations = [],
  runLimit = 0,
}) {
  const tasks = [];
  let scheduledRuns = 0;
  const normalizedLimit =
    Number.isFinite(Number(runLimit)) && Number(runLimit) > 0
      ? Number(runLimit)
      : teamCombinations.length * liquidRolls.length * rotations.length;

  for (const teamCombo of teamCombinations) {
    for (const liquidRoll of liquidRolls) {
      const remaining = normalizedLimit - scheduledRuns;
      if (remaining <= 0) {
        return { tasks, scheduledRuns };
      }
      const taskRotations = rotations.slice(0, remaining);
      tasks.push({
        teamCombo,
        liquidRolls: liquidRoll,
        rotations: taskRotations,
      });
      scheduledRuns += taskRotations.length;
    }
  }

  return { tasks, scheduledRuns };
}
