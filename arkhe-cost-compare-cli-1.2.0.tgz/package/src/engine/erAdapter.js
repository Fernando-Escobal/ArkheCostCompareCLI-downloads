import fs from "fs";
import os from "os";
import path from "path";
import { runProcess } from "../utils/proc.js";

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function appendErDebug(debug, payload) {
  if (!debug?.enabled || !debug?.filePath) return;
  try {
    const dirPath = path.dirname(debug.filePath);
    ensureDir(dirPath);
    fs.appendFileSync(
      debug.filePath,
      `${JSON.stringify({
        ts: new Date().toISOString(),
        scenarioName: debug.scenarioName || "",
        rotationId: debug.rotationId || "",
        rotationLabel: debug.rotationLabel || "",
        energySignature: debug.energySignature || "",
        favMask: debug.favMask || "",
        mode: debug.mode || "runtime",
        ...payload,
      })}\n`,
      "utf8",
    );
  } catch {
    // best-effort debug logging only
  }
}

function summarizeTeam(teamCombo) {
  return (teamCombo || []).map((member) => ({
    character: normalizeId(member?.character),
    cons: Number(member?.cons || 0),
    weapon: normalizeId(member?.weapon),
    set: normalizeId(member?.set),
  }));
}

function normalizeId(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function sanitizeAdditionalER(value) {
  const num = Number(value);
  if (!Number.isFinite(num) || num < 0) return 0;
  if (num > 4) return 4;
  return Math.round(num * 100) / 100;
}

function isFavoniusWeapon(weaponId) {
  const weapon = normalizeId(weaponId).replace(/^r\d+/i, "");
  return weapon.includes("fav") && !weapon.includes("aquila");
}

function isXiphosWeapon(weaponId) {
  const weapon = normalizeId(weaponId).replace(/^r\d+/i, "");
  return weapon.includes("xiphos");
}

function buildBaselineErConfig({
  teamCombo,
  rotationGcsl,
  iterations = 1,
  favSetup = [],
  additionalERByCharacter = {},
}) {
  return buildBaselineGcsl({
    teamCombo,
    rotationGcsl,
    iterations,
    favSetup,
    additionalERByCharacter,
  });
}

function buildBaselineGcsl({
  teamCombo,
  rotationGcsl,
  iterations = 1,
  favSetup = [],
  additionalERByCharacter = {},
}) {
  const lines = [];
  const firstCharacter = String(teamCombo?.[0]?.character || "").toLowerCase();
  const favSet = new Set((favSetup || []).map((entry) => normalizeId(entry)));

  for (const member of teamCombo || []) {
    const name = String(member.character || "").toLowerCase();
    if (!name) continue;
    const additionalER = sanitizeAdditionalER(
      additionalERByCharacter?.[name] || 0,
    );
    const baseER = favSet.has(name) ? -0.613 : 0;
    const finalER = baseER + additionalER;
    lines.push(
      `${name} char lvl=90/90 cons=${Number(member?.cons || 0)} talent=9,9,9;`,
    );
    lines.push(
      `${name} add weapon="${favSet.has(name) ? "favsword" : "dullblade"}" refine=5 lvl=90/90;`,
    );
    lines.push(
      `${name} add stats hp=4780 atk=311 atk%=0.466 hp%=0.466 cr=1 er=${finalER};`,
    );
    lines.push("");
  }

  if (firstCharacter) {
    lines.push(`active ${firstCharacter};`);
    lines.push("");
  }

  lines.push("# Options");
  lines.push(`options swap_delay=12 iteration=${Number(iterations) || 1};`);
  lines.push("target lvl=100 resist=0.1 radius=2 pos=0,2.5 hp=999999999;");
  lines.push("energy every interval=480,720 amount=1;");
  lines.push("");
  lines.push("# Rotation");
  lines.push(String(rotationGcsl || "").trim());

  return lines.join("\n");
}

async function computeBaseERWithoutFavonius({
  gcsimPath,
  teamCombo,
  rotationGcsl,
  erIterations,
  erPercentile,
  tempDir,
  keepTemp,
  timeoutMs,
  debug,
}) {
  const raw = await computeAdditionalERMap({
    gcsimPath,
    teamCombo,
    rotationGcsl,
    erIterations,
    erPercentile,
    tempDir,
    keepTemp,
    timeoutMs,
    debug,
  });
  return raw.additionalERByCharacter || {};
}

export async function computeAdditionalERMap({
  gcsimPath,
  teamCombo,
  rotationGcsl,
  erIterations = 350,
  erPercentile = 0.8,
  tempDir,
  keepTemp = false,
  timeoutMs = 120000,
  debug,
  favSetup = [],
  additionalERByCharacter = {},
}) {
  const baseTemp = tempDir || path.join(os.tmpdir(), "arkhe-cc");
  ensureDir(baseTemp);

  const jobId = `er-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const cfgPath = path.join(baseTemp, `${jobId}.txt`);
  const outPath = path.join(baseTemp, `${jobId}.json`);

  const baseline = buildBaselineErConfig({
    teamCombo,
    rotationGcsl,
    iterations: 1,
    favSetup,
    additionalERByCharacter,
  });
  fs.writeFileSync(cfgPath, baseline, "utf8");

  const args = [
    "-c",
    cfgPath,
    "-erNeeded",
    "-erIterations",
    String(Number(erIterations) || 350),
    "-erPercentile",
    String(Number(erPercentile) || 0.8),
    "-out",
    outPath,
  ];

  appendErDebug(debug, {
    phase: "erNeeded:start",
    gcsimPath,
    args,
    team: summarizeTeam(teamCombo),
  });

  try {
    const exec = await runProcess(gcsimPath, args, { timeoutMs });
    if (exec.code !== 0) {
      throw new Error(
        `gcsim ER mode exited with code ${exec.code}. stderr: ${exec.stderr || "(empty)"}`,
      );
    }

    if (!fs.existsSync(outPath)) {
      throw new Error("gcsim ER mode did not generate output file");
    }

    const raw = JSON.parse(fs.readFileSync(outPath, "utf8"));
    const items = Array.isArray(raw) ? raw : [];

    appendErDebug(debug, {
      phase: "erNeeded:raw-output",
      outputPath: outPath,
      itemCount: items.length,
      items,
    });

    const additionalERByCharacter = {};
    const meta = {};

    items.forEach((item) => {
      const key = String(item?.name || "").toLowerCase();
      if (!key) return;
      const additionalER = Number(item?.additionalER || 0);
      additionalERByCharacter[key] = Number.isFinite(additionalER)
        ? Math.max(0, Math.min(4, additionalER))
        : 0;
      meta[key] = {
        recommendedERSubs: Number(item?.recommendedERSubs || 0),
        maxExtraERSubs: Number(item?.maxExtraERSubs || 0),
      };
    });

    return { additionalERByCharacter, meta, raw: items };
  } finally {
    if (!keepTemp) {
      try {
        if (fs.existsSync(cfgPath)) fs.unlinkSync(cfgPath);
      } catch {}
      try {
        if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
      } catch {}
    }
  }
}

export async function computeERForTeam({
  gcsimPath,
  teamCombo,
  rotationGcsl,
  erIterations = 350,
  erPercentile = 0.8,
  tempDir,
  keepTemp = false,
  timeoutMs = 120000,
  debug,
}) {
  appendErDebug(debug, {
    phase: "computeER:start",
    erIterations,
    erPercentile,
    team: summarizeTeam(teamCombo),
  });

  const base = await computeBaseERWithoutFavonius({
    gcsimPath,
    teamCombo,
    rotationGcsl,
    erIterations,
    erPercentile,
    tempDir,
    keepTemp,
    timeoutMs,
    debug,
  });

  appendErDebug(debug, {
    phase: "computeER:base-without-favonius",
    base,
  });

  const favSetup = (teamCombo || [])
    .filter((member) => isFavoniusWeapon(member?.weapon))
    .map((member) => normalizeId(member.character));

  let result = { ...base };

  if (favSetup.length > 0) {
    const favMap = await computeAdditionalERMap({
      gcsimPath,
      teamCombo,
      rotationGcsl,
      erIterations,
      erPercentile,
      tempDir,
      keepTemp,
      timeoutMs,
      debug,
      favSetup,
      additionalERByCharacter: {},
    });

    appendErDebug(debug, {
      phase: "computeER:favonius-direct-map",
      favSetup,
      result: favMap.additionalERByCharacter || {},
    });
    result = { ...(favMap.additionalERByCharacter || {}) };
  }

  const hasXiphos = (teamCombo || []).some((member) =>
    isXiphosWeapon(member?.weapon),
  );
  if (hasXiphos) {
    const beforeXiphos = { ...result };
    result = Object.fromEntries(
      Object.entries(result).map(([key, value]) => [
        key,
        sanitizeAdditionalER(Number(value || 0) - 0.08),
      ]),
    );

    appendErDebug(debug, {
      phase: "computeER:xiphos-adjustment",
      before: beforeXiphos,
      after: result,
    });
  }

  appendErDebug(debug, {
    phase: "computeER:final",
    result,
  });

  return result;
}
