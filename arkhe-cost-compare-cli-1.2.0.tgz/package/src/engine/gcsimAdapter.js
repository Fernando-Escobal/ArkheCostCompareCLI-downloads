import fs from "fs";
import os from "os";
import path from "path";
import { runProcess } from "../utils/proc.js";

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

export function extractSimulationMetrics(result) {
  const stats = result?.statistics || result?.stats || {};

  const dpsMeanCandidates = [
    stats?.dps?.mean,
    result?.dps,
    result?.damage,
    result?.result?.dps,
  ];
  const dps = dpsMeanCandidates.find((v) => Number.isFinite(Number(v)));

  const durationCandidates = [
    stats?.duration?.mean,
    result?.duration,
    result?.sim_duration,
  ];
  const duration = durationCandidates.find((v) => Number.isFinite(Number(v)));

  let characterDps = [];
  if (Array.isArray(stats?.character_dps)) {
    characterDps = stats.character_dps.map((row) => Number(row?.mean || 0));
  } else if (Array.isArray(result?.characters)) {
    characterDps = result.characters.map((row) =>
      Number(row?.damage?.total || 0),
    );
  }

  return {
    dps: Number.isFinite(Number(dps)) ? Number(dps) : 0,
    duration: Number.isFinite(Number(duration)) ? Number(duration) : 0,
    characterDps,
    raw: result,
  };
}

export async function runGcsimConfig({
  gcsimPath,
  configText,
  timeoutMs = 120000,
  tempDir,
  keepTemp = false,
  verbose = false,
}) {
  const baseTemp = tempDir || path.join(os.tmpdir(), "arkhe-cc");
  ensureDir(baseTemp);

  const jobId = `job-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const cfgPath = path.join(baseTemp, `${jobId}.txt`);
  const outPath = path.join(baseTemp, `${jobId}.json`);

  fs.writeFileSync(cfgPath, configText, "utf8");

  const args = ["-c", cfgPath, "-out", outPath];
  if (verbose) args.push("-v");

  try {
    const exec = await runProcess(gcsimPath, args, { timeoutMs });
    if (exec.code !== 0) {
      throw new Error(
        `gcsim exited with code ${exec.code}. stderr: ${exec.stderr || "(empty)"}`,
      );
    }

    if (!fs.existsSync(outPath)) {
      throw new Error("gcsim did not generate output file");
    }

    const parsed = JSON.parse(fs.readFileSync(outPath, "utf8"));
    return extractSimulationMetrics(parsed);
  } finally {
    if (!keepTemp) {
      try {
        if (fs.existsSync(cfgPath)) fs.unlinkSync(cfgPath);
      } catch {}
      try {
        if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
      } catch {}
    }
  }
}
