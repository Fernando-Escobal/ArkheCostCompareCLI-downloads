import path from "path";
import { pathToFileURL } from "url";
import { withSilencedConsole } from "../utils/logging.js";
import { resolveBackendRuntimePath } from "../utils/runtimePaths.js";

function isLikelyGcslRotation(text) {
  const raw = String(text || "").toLowerCase();
  return (
    raw.includes("for let i") || raw.includes(";\n") || raw.includes("active ")
  );
}

export async function normalizeRotationInput({
  rotationInput,
  rots = 4,
  operation = "calc",
  backendRuntimePath,
  scenarioBaseDir,
  verbose = false,
}) {
  const raw = String(rotationInput || "").trim();
  if (!raw) return "";

  if (isLikelyGcslRotation(raw)) {
    return raw;
  }

  const runtimeBackendPath = resolveBackendRuntimePath({
    scenarioBaseDir,
    backendRuntimePath,
  });

  const parserModulePath = path.resolve(
    runtimeBackendPath,
    "modules",
    "kqmToGcslParser.js",
  );
  const charactersPath = path.resolve(
    runtimeBackendPath,
    "data",
    "characters.json",
  );

  const prevCwd = process.cwd();
  try {
    // Parser reads characterVars from a relative path during module lifecycle.
    // Ensure relative reads resolve against the vendored backend root.
    process.chdir(runtimeBackendPath);
    const gcsl = await withSilencedConsole(
      ["log", "info", "debug", "warn"],
      !verbose,
      async () => {
        const parserModule = await import(pathToFileURL(parserModulePath).href);
        const parseKQMToGCSL = parserModule?.parseKQMToGCSL;
        if (typeof parseKQMToGCSL !== "function") {
          throw new Error(
            "Could not load parseKQMToGCSL from backend parser module",
          );
        }
        return parseKQMToGCSL(
          raw,
          charactersPath,
          Number(rots) || 4,
          operation,
        );
      },
    );
    return String(gcsl || "").trim();
  } finally {
    process.chdir(prevCwd);
  }
}
