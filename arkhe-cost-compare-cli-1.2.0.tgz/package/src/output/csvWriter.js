import fs from "fs";
import path from "path";
import { resolveFromBase } from "../utils/paths.js";

function ensureDirForFile(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function escapeCsv(value) {
  const raw = String(value ?? "");
  if (/[",\n]/.test(raw)) {
    return `"${raw.replace(/"/g, '""')}"`;
  }
  return raw;
}

export function writeResultsCsv({ rows, rotations, outputPath, baseDir }) {
  const resolvedOutput = resolveFromBase(baseDir, outputPath);
  ensureDirForFile(resolvedOutput);

  const rotationCols = (rotations || []).map(
    (r, idx) =>
      `damage_rot_${String(r.label || r.id || idx + 1)
        .replace(/\s+/g, "_")
        .toLowerCase()}`,
  );

  const headers = [
    "index",
    "char1",
    "char1Cons",
    "char1WeaponRefinement",
    "char1Set",
    "char1MainStats",
    "char2",
    "char2Cons",
    "char2WeaponRefinement",
    "char2Set",
    "char2MainStats",
    "char3",
    "char3Cons",
    "char3WeaponRefinement",
    "char3Set",
    "char3MainStats",
    "char4",
    "char4Cons",
    "char4WeaponRefinement",
    "char4Set",
    "char4MainStats",
    "cost",
    "liquidRolls",
    ...rotationCols,
    "char1AvgPct",
    "char2AvgPct",
    "char3AvgPct",
    "char4AvgPct",
    "totalDPS",
    "duration",
  ];

  const lines = [headers.join(",")];

  rows.forEach((row, idx) => {
    const values = [
      idx + 1,
      row.char1,
      row.char1Cons,
      row.char1WeaponRefinement,
      row.char1Set,
      row.char1MainStats,
      row.char2,
      row.char2Cons,
      row.char2WeaponRefinement,
      row.char2Set,
      row.char2MainStats,
      row.char3,
      row.char3Cons,
      row.char3WeaponRefinement,
      row.char3Set,
      row.char3MainStats,
      row.char4,
      row.char4Cons,
      row.char4WeaponRefinement,
      row.char4Set,
      row.char4MainStats,
      row.cost,
      row.liquidRolls,
      ...rotationCols.map((col) => Number(row[col] || 0).toFixed(2)),
      row.char1AvgPct,
      row.char2AvgPct,
      row.char3AvgPct,
      row.char4AvgPct,
      Number(row.totalDPS || 0).toFixed(2),
      Number(row.duration || 0).toFixed(2),
    ];
    lines.push(values.map(escapeCsv).join(","));
  });

  fs.writeFileSync(resolvedOutput, `\uFEFF${lines.join("\n")}`, "utf8");
  return resolvedOutput;
}
