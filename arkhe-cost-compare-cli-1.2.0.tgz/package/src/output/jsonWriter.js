import fs from "fs";
import path from "path";
import { resolveFromBase } from "../utils/paths.js";

export function writeResultsJson({ payload, outputPath, baseDir }) {
  if (!outputPath) return "";

  const resolvedOutput = resolveFromBase(baseDir, outputPath);
  const dir = path.dirname(resolvedOutput);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.writeFileSync(resolvedOutput, JSON.stringify(payload, null, 2), "utf8");
  return resolvedOutput;
}
