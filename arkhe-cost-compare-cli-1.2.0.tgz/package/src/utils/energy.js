export function buildEnergySignature(teamCombo = []) {
  return teamCombo
    .map((member) => {
      const character = String(member?.character || "").toLowerCase();
      const weapon = String(member?.weapon || "").toLowerCase();
      return `${character}|${weapon}`;
    })
    .join("||");
}
