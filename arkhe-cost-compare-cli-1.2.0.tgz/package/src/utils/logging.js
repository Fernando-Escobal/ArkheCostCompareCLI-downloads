export async function withSilencedConsole(methods, enabled, fn) {
  if (!enabled) {
    return fn();
  }

  const originals = new Map();
  for (const method of methods) {
    originals.set(method, console[method]);
    console[method] = () => {};
  }

  try {
    return await fn();
  } finally {
    for (const method of methods) {
      console[method] = originals.get(method);
    }
  }
}
