import path from "path";

export function resolveFromCwd(inputPath) {
  if (!inputPath) return process.cwd();
  return path.isAbsolute(inputPath)
    ? inputPath
    : path.resolve(process.cwd(), inputPath);
}

export function resolveFromBase(basePath, targetPath) {
  if (!targetPath) return basePath;
  return path.isAbsolute(targetPath)
    ? targetPath
    : path.resolve(basePath, targetPath);
}
