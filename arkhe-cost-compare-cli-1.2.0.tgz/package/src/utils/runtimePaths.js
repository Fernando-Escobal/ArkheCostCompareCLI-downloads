import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { resolveFromBase, resolveFromCwd } from "./paths.js";

function getCliRoot() {
  const currentFile = fileURLToPath(import.meta.url);
  return path.resolve(path.dirname(currentFile), "..", "..");
}

export function getVendoredBackendRoot() {
  return path.resolve(getCliRoot(), "vendor", "backend");
}

/**
 * Ensures the file at filePath has the executable bit set on Linux/macOS.
 * On Windows this is a no-op. Returns true if the permission was applied.
 */
export function ensureExecutable(filePath) {
  if (process.platform === "win32") return false;
  try {
    const stat = fs.statSync(filePath);
    if (!(stat.mode & 0o111)) {
      fs.chmodSync(filePath, stat.mode | 0o111);
      return true;
    }
  } catch {
    // ignore — the caller will get the real error on spawn
  }
  return false;
}

export function resolveBackendRuntimePath({ strict = true } = {}) {
  const fallbackVendored = getVendoredBackendRoot();

  const modulesPath = path.resolve(fallbackVendored, "modules");
  const dataPath = path.resolve(fallbackVendored, "data");
  if (fs.existsSync(modulesPath) && fs.existsSync(dataPath)) {
    return fallbackVendored;
  }

  if (!strict) {
    return fallbackVendored;
  }

  throw new Error(
    "Could not resolve backend runtime path. Expected vendor/backend with modules and data.",
  );
}

export function resolveGcsimExecutablePath({
  scenarioBaseDir,
  gcsimPath,
  cliOverridePath,
  strict = true,
} = {}) {
  const override = String(cliOverridePath || "").trim();
  const scenarioValue = String(gcsimPath || "").trim();

  const candidates = [];

  if (override) {
    candidates.push(resolveFromCwd(override));
  }

  if (scenarioValue) {
    candidates.push(
      resolveFromBase(scenarioBaseDir || process.cwd(), scenarioValue),
    );
  }

  const base = scenarioBaseDir || process.cwd();
  const defaultBinaryNames =
    process.platform === "win32"
      ? ["gcsim.exe", "gcsim_windows_amd64.exe"]
      : process.platform === "linux"
        ? ["gcsim", "gcsim_linux_amd64"]
        : process.platform === "darwin"
          ? ["gcsim", "gcsim_darwin_arm64", "gcsim_darwin_amd64"]
          : ["gcsim", "gcsim.exe"];

  defaultBinaryNames.forEach((name) => {
    candidates.push(path.resolve(base, "..", "gcsim", name));
    candidates.push(resolveFromCwd(`../gcsim/${name}`));
  });

  const seen = new Set();
  const uniqueCandidates = candidates.filter((entry) => {
    const key = path.resolve(entry);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const existing = uniqueCandidates.find((entry) => fs.existsSync(entry));
  if (existing) return existing;

  if (!strict) {
    return uniqueCandidates[0] || "";
  }

  throw new Error(
    `Could not find gcsim executable. Tried: ${uniqueCandidates.join(", ")}`,
  );
}
