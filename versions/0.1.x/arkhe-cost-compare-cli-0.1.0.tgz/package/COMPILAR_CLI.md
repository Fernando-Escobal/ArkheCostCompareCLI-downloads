﻿# Compilar el CLI

Este proyecto no requiere transpilacion. El CLI se ejecuta directamente con Node.js.

## Requisitos

- Node.js 18+
- gcsim.exe disponible localmente

## Estructura minima

```text
ArkheCostCompareCLI/
  bin/
  src/
  vendor/
    backend/
  package.json
  example.scenario.txt
```

## Ejecucion

```powershell
node .\\bin\\arkhe-cc.js doctor
node .\\bin\\arkhe-cc.js dry-run --scenario .\\example.scenario.txt
node .\\bin\\arkhe-cc.js run --scenario .\\example.scenario.txt
```

## Empaquetado

Puedes distribuir la carpeta completa en .zip o usar:

```powershell
npm pack
```

## Notas

- El CLI no compila gcsim; solo lo ejecuta.
- La logica de parseo y build esta integrada en vendor/backend.
- Si gcsimPath no esta definido en el scenario, se usa ../gcsim/gcsim.exe.
