﻿# Arkhe Cost Compare CLI

CLI local para comparar combinaciones de equipo y constelaciones usando gcsim.exe.

## Documentacion

- COMPILAR_CLI.md
- PREPARAR_ENTORNO.md
- GENERAR_SCENARIO_TXT.md

## Modo de ejecucion

- Parser y builder estan integrados en vendor/backend.
- La simulacion se ejecuta con gcsim.exe local.
- simulation.gcsimPath es opcional.
- Si gcsimPath esta vacio, el CLI intenta ../gcsim/gcsim.exe.

## Comandos

```powershell
node .\\bin\\arkhe-cc.js doctor
node .\\bin\\arkhe-cc.js dry-run --scenario .\\example.scenario.txt
node .\\bin\\arkhe-cc.js run --scenario .\\example.scenario.txt
```
