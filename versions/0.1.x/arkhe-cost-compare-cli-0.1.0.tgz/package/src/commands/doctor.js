import fs from "fs";
import { runProcess } from "../utils/proc.js";
import path from "path";
import { resolveGcsimExecutablePath } from "../utils/runtimePaths.js";

export async function runDoctor(options = {}) {
  const scenarioBaseDir = options.scenario
    ? path.dirname(path.resolve(process.cwd(), options.scenario))
    : process.cwd();

  const gcsimPath = resolveGcsimExecutablePath({
    scenarioBaseDir,
    gcsimPath: options.gcsimPath,
    cliOverridePath: options.gcsimPath,
    strict: false,
  });

  const checks = [];

  checks.push({
    name: "gcsim path exists",
    ok: fs.existsSync(gcsimPath),
    details: gcsimPath,
  });

  if (checks[0].ok) {
    try {
      const result = await runProcess(gcsimPath, ["-version"], {
        timeoutMs: 10000,
      });
      checks.push({
        name: "gcsim executable",
        ok: result.code === 0,
        details:
          result.stdout.trim() ||
          result.stderr.trim() ||
          `exit code ${result.code}`,
      });
    } catch (err) {
      checks.push({
        name: "gcsim executable",
        ok: false,
        details: err.message,
      });
    }
  }

  const allOk = checks.every((c) => c.ok);

  console.log("[doctor] checks:");
  checks.forEach((check) => {
    console.log(
      `- ${check.ok ? "OK" : "FAIL"} ${check.name}: ${check.details}`,
    );
  });

  if (!allOk) {
    throw new Error("Doctor checks failed");
  }

  console.log("[doctor] environment is ready");
}
