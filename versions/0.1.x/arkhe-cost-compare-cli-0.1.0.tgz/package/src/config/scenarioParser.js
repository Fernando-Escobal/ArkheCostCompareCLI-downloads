import fs from "fs";

function normalizeKey(key) {
  return String(key || "")
    .trim()
    .toLowerCase();
}

function parseBoolean(value, fallback = false) {
  const raw = String(value || "")
    .trim()
    .toLowerCase();
  if (["true", "1", "yes", "y"].includes(raw)) return true;
  if (["false", "0", "no", "n"].includes(raw)) return false;
  return fallback;
}

function parseNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function parseConsOptions(raw) {
  const normalized = String(raw || "").trim();
  if (!normalized) return [];
  return Array.from(
    new Set(
      normalized
        .split("|")
        .map((v) => Number(v.trim()))
        .filter((v) => Number.isInteger(v)),
    ),
  ).sort((a, b) => a - b);
}

function parseLiquidRolls(raw) {
  const normalized = String(raw || "").trim();
  if (!normalized) return [];
  return Array.from(
    new Set(
      normalized
        .split(",")
        .map((v) => Number(v.trim()))
        .filter((v) => Number.isInteger(v)),
    ),
  ).sort((a, b) => a - b);
}

export function parseScenarioFile(filePath) {
  const text = fs.readFileSync(filePath, "utf8");
  const lines = text.replace(/\r\n/g, "\n").split("\n");

  const sections = {};
  let currentSection = "";

  lines.forEach((rawLine, index) => {
    const lineNumber = index + 1;
    const line = rawLine.trim();
    if (!line || line.startsWith("#") || line.startsWith(";")) return;

    const sectionMatch = line.match(/^\[([^\]]+)\]$/);
    if (sectionMatch) {
      currentSection = normalizeKey(sectionMatch[1]);
      if (!sections[currentSection]) sections[currentSection] = [];
      return;
    }

    const eqIndex = line.indexOf("=");
    if (eqIndex === -1) {
      throw new Error(`Invalid line ${lineNumber}: expected key=value`);
    }

    if (!currentSection) {
      throw new Error(
        `Invalid line ${lineNumber}: key=value appears before any [section]`,
      );
    }

    const key = normalizeKey(line.slice(0, eqIndex));
    const value = line.slice(eqIndex + 1).trim();
    sections[currentSection].push({ key, value, line: lineNumber });
  });

  const getSectionMap = (sectionName) => {
    const rows = sections[sectionName] || [];
    return Object.fromEntries(rows.map((r) => [r.key, r.value]));
  };

  const metaMap = getSectionMap("meta");
  const simulationMap = getSectionMap("simulation");
  const selectionMap = getSectionMap("selection");
  const outputMap = getSectionMap("output");

  const rotationRows = sections.rotations || [];
  const rotationMap = new Map();
  rotationRows.forEach(({ key, value }) => {
    const match = key.match(/^(r\d+)\.(label|weight|input)$/);
    if (!match) return;
    const id = match[1];
    const field = match[2];
    const item = rotationMap.get(id) || { id, label: "", input: "", weight: 0 };
    item[field] = field === "weight" ? parseNumber(value, 0) : value;
    rotationMap.set(id, item);
  });

  const teamRows = sections.team || [];
  const teamMap = new Map();
  teamRows.forEach(({ key, value }) => {
    const match = key.match(
      /^(slot[1-4])\.(character|cons|weapon4|weapon5|set|main)$/,
    );
    if (!match) return;
    const slotKey = match[1];
    const field = match[2];
    const item = teamMap.get(slotKey) || {
      slot: Number(slotKey.replace("slot", "")),
      character: "",
      cons: "",
      weapon4: "",
      weapon5: "",
      set: "",
      main: "",
    };
    item[field] = value;
    teamMap.set(slotKey, item);
  });

  const scenario = {
    meta: {
      name: metaMap.name || "",
      version: metaMap.version || "1",
    },
    simulation: {
      iterations: parseNumber(simulationMap.iterations, 100),
      rots: parseNumber(simulationMap.rots, 4),
      parallel: parseNumber(simulationMap.parallel, 4),
      timeoutMs: parseNumber(simulationMap.timeoutms, 120000),
      gcsimPath: simulationMap.gcsimpath || "",
      erIterations: parseNumber(simulationMap.eriterations, 350),
      erPercentile: Number(simulationMap.erpercentile || 0.8),
      enableER: parseBoolean(simulationMap.enableer, false),
      substatOptim: parseBoolean(simulationMap.substatoptim, false),
      gcsimVerbose: parseBoolean(simulationMap.gcsimverbose, false),
    },
    rotations: Array.from(rotationMap.values()).map((r) => ({
      id: r.id,
      label: r.label || r.id,
      input: r.input || "",
      weightPercent: Number(r.weight || 0),
    })),
    team: Array.from(teamMap.values())
      .sort((a, b) => a.slot - b.slot)
      .map((member) => ({
        slot: member.slot,
        character: String(member.character || "").trim(),
        consOptions: parseConsOptions(member.cons),
        weapon4: String(member.weapon4 || "").trim(),
        weapon5: String(member.weapon5 || "").trim(),
        set: String(member.set || "").trim(),
        main: String(member.main || "").trim(),
      })),
    selection: {
      liquidRolls: parseLiquidRolls(selectionMap.liquidrolls),
      requireWeight100: parseBoolean(selectionMap.requireweight100, true),
    },
    output: {
      csvPath: outputMap.csv || "./out/results.csv",
      jsonPath: outputMap.json || "",
      sortBy: outputMap.sortby || "weightedDps",
      sortDir: outputMap.sortdir || "desc",
      topN: parseNumber(outputMap.topn, 0),
      keepTemp: parseBoolean(outputMap.keeptemp, false),
      tempDir: outputMap.tempdir || "./.tmp",
    },
  };

  return scenario;
}
