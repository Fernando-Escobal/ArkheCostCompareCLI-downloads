import fs from "fs";
import os from "os";
import path from "path";
import { runProcess } from "../utils/proc.js";
import { runGcsimConfig } from "./gcsimAdapter.js";
import { resolveBackendRuntimePath } from "../utils/runtimePaths.js";

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

let charactersCache = null;

function normalizeId(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function sanitizeAdditionalER(value) {
  const num = Number(value);
  if (!Number.isFinite(num) || num < 0) return 0;
  if (num > 4) return 4;
  return Math.round(num * 100) / 100;
}

function isFavoniusWeapon(weaponId) {
  const weapon = normalizeId(weaponId).replace(/^r\d+/i, "");
  return weapon.includes("fav") && !weapon.includes("aquila");
}

function isXiphosWeapon(weaponId) {
  const weapon = normalizeId(weaponId).replace(/^r\d+/i, "");
  return weapon.includes("xiphos");
}

function loadCharactersData(backendRuntimePath) {
  if (charactersCache) return charactersCache;
  const filePath = path.resolve(backendRuntimePath, "data", "characters.json");
  const raw = fs.readFileSync(filePath, "utf8");
  charactersCache = JSON.parse(raw);
  return charactersCache;
}

function findCharacterData(backendRuntimePath, characterId) {
  const characters = loadCharactersData(backendRuntimePath);
  const normalized = normalizeId(characterId);
  return characters.find(
    (entry) =>
      normalizeId(entry?.character) === normalized ||
      normalizeId(entry?.name) === normalized,
  );
}

function buildBaselineErConfig(teamCombo, rotationGcsl, iterations = 1) {
  return buildBaselineGcsl({ teamCombo, rotationGcsl, iterations });
}

function buildBaselineGcsl({
  teamCombo,
  rotationGcsl,
  iterations = 1,
  favSetup = [],
  additionalERByCharacter = {},
}) {
  const lines = [];
  const firstCharacter = String(teamCombo?.[0]?.character || "").toLowerCase();
  const favSet = new Set((favSetup || []).map((entry) => normalizeId(entry)));

  for (const member of teamCombo || []) {
    const name = String(member.character || "").toLowerCase();
    if (!name) continue;
    const additionalER = sanitizeAdditionalER(
      additionalERByCharacter?.[name] || 0,
    );
    const baseER = favSet.has(name) ? -0.613 : 0;
    const finalER = baseER + additionalER;
    lines.push(
      `${name} char lvl=90/90 cons=${Number(member?.cons || 0)} talent=9,9,9;`,
    );
    lines.push(
      `${name} add weapon="${favSet.has(name) ? "favsword" : "dullblade"}" refine=5 lvl=90/90;`,
    );
    lines.push(
      `${name} add stats hp=4780 atk=311 atk%=0.466 hp%=0.466 cr=1 er=${finalER};`,
    );
    lines.push("");
  }

  if (firstCharacter) {
    lines.push(`active ${firstCharacter};`);
    lines.push("");
  }

  lines.push("# Options");
  lines.push(`options swap_delay=12 iteration=${Number(iterations) || 1};`);
  lines.push("target lvl=100 resist=0.1 radius=2 pos=0,2.5 hp=999999999;");
  lines.push("energy every interval=480,720 amount=1;");
  lines.push("");
  lines.push("# Rotation");
  lines.push(String(rotationGcsl || "").trim());

  return lines.join("\n");
}

function calculateFavoniusEnergyContribution(
  simulation,
  additionalERByCharacter,
  backendRuntimePath,
) {
  try {
    const charArrayFav = Array.isArray(simulation?.raw?.characters)
      ? simulation.raw.characters
      : Array.isArray(simulation?.characters)
        ? simulation.characters
        : [];

    if (charArrayFav.length === 0) {
      return [];
    }

    return charArrayFav.map((charFav) => {
      const normalized = normalizeId(charFav?.name);
      const characterData = findCharacterData(backendRuntimePath, normalized);
      const additionalValue = sanitizeAdditionalER(
        additionalERByCharacter?.[normalized] || 0,
      );
      const burstCostValue = Number(characterData?.burstCost || 0);
      const ascensionERValue = Number(characterData?.ascensionStat?.value || 0);

      const energyEventsFav = Array.isArray(charFav?.energy_events)
        ? charFav.energy_events
        : [];
      const favoniusEvents = energyEventsFav.filter(
        (evt) =>
          evt &&
          typeof evt.source === "string" &&
          evt.source.toLowerCase().includes("favonius"),
      );
      const nonFavoniusEvents = energyEventsFav.filter(
        (evt) =>
          evt &&
          typeof evt.source === "string" &&
          !evt.source.toLowerCase().includes("favonius"),
      );

      const favoniusEnergyGained = favoniusEvents.reduce(
        (sum, evt) =>
          sum + (Number.isFinite(Number(evt?.gained)) ? Number(evt.gained) : 0),
        0,
      );
      const nonFavoniusEnergyGained = nonFavoniusEvents.reduce(
        (sum, evt) =>
          sum + (Number.isFinite(Number(evt?.gained)) ? Number(evt.gained) : 0),
        0,
      );

      const actionEvents = Array.isArray(charFav?.action_events)
        ? charFav.action_events
        : [];
      const burstCount = Math.max(
        actionEvents.filter((event) => event && event.action === "burst")
          .length,
        1,
      );
      const charER = ascensionERValue + 1;

      if (burstCostValue <= 0 || charER <= 0 || nonFavoniusEnergyGained <= 0) {
        return 0;
      }

      let favPerBurstContribution = favoniusEnergyGained / burstCount / charER;
      const energyRequiredWithoutFavonius =
        burstCostValue / (nonFavoniusEnergyGained / burstCount / charER);

      favPerBurstContribution =
        ((energyRequiredWithoutFavonius * 100) /
          (charER + additionalValue) /
          100) *
        favPerBurstContribution *
        0.905136;

      return Number.isFinite(favPerBurstContribution)
        ? favPerBurstContribution
        : 0;
    });
  } catch {
    return [];
  }
}

function calcERAdjustmentForFavonius(
  burstCost,
  ascensionER,
  additionalER,
  erFromFavonius = 3.6,
) {
  const adjustedER =
    burstCost / (1 + additionalER + ascensionER) + erFromFavonius;
  return burstCost / adjustedER - 1.1102;
}

async function computeBaseERWithoutFavonius({
  gcsimPath,
  teamCombo,
  rotationGcsl,
  erIterations,
  erPercentile,
  tempDir,
  keepTemp,
  timeoutMs,
}) {
  const raw = await computeAdditionalERMap({
    gcsimPath,
    teamCombo,
    rotationGcsl,
    erIterations,
    erPercentile,
    tempDir,
    keepTemp,
    timeoutMs,
  });
  return raw.additionalERByCharacter || {};
}

export async function computeAdditionalERMap({
  gcsimPath,
  teamCombo,
  rotationGcsl,
  erIterations = 350,
  erPercentile = 0.8,
  tempDir,
  keepTemp = false,
  timeoutMs = 120000,
}) {
  const baseTemp = tempDir || path.join(os.tmpdir(), "arkhe-cc");
  ensureDir(baseTemp);

  const jobId = `er-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const cfgPath = path.join(baseTemp, `${jobId}.txt`);
  const outPath = path.join(baseTemp, `${jobId}.json`);

  const baseline = buildBaselineErConfig(teamCombo, rotationGcsl, 1);
  fs.writeFileSync(cfgPath, baseline, "utf8");

  const args = [
    "-c",
    cfgPath,
    "-erNeeded",
    "-erIterations",
    String(Number(erIterations) || 350),
    "-erPercentile",
    String(Number(erPercentile) || 0.8),
    "-out",
    outPath,
  ];

  try {
    const exec = await runProcess(gcsimPath, args, { timeoutMs });
    if (exec.code !== 0) {
      throw new Error(
        `gcsim ER mode exited with code ${exec.code}. stderr: ${exec.stderr || "(empty)"}`,
      );
    }

    if (!fs.existsSync(outPath)) {
      throw new Error("gcsim ER mode did not generate output file");
    }

    const raw = JSON.parse(fs.readFileSync(outPath, "utf8"));
    const items = Array.isArray(raw) ? raw : [];

    const additionalERByCharacter = {};
    const meta = {};

    items.forEach((item) => {
      const key = String(item?.name || "").toLowerCase();
      if (!key) return;
      const additionalER = Number(item?.additionalER || 0);
      additionalERByCharacter[key] = Number.isFinite(additionalER)
        ? Math.max(0, Math.min(4, additionalER))
        : 0;
      meta[key] = {
        recommendedERSubs: Number(item?.recommendedERSubs || 0),
        maxExtraERSubs: Number(item?.maxExtraERSubs || 0),
      };
    });

    return { additionalERByCharacter, meta, raw: items };
  } finally {
    if (!keepTemp) {
      try {
        if (fs.existsSync(cfgPath)) fs.unlinkSync(cfgPath);
      } catch {}
      try {
        if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
      } catch {}
    }
  }
}

export async function computeERForTeam({
  gcsimPath,
  teamCombo,
  rotationGcsl,
  backendRuntimePath,
  scenarioBaseDir,
  erIterations = 350,
  erPercentile = 0.8,
  tempDir,
  keepTemp = false,
  timeoutMs = 120000,
}) {
  const runtimeBackendPath = resolveBackendRuntimePath({
    scenarioBaseDir,
    backendRuntimePath,
  });

  const base = await computeBaseERWithoutFavonius({
    gcsimPath,
    teamCombo,
    rotationGcsl,
    erIterations,
    erPercentile,
    tempDir,
    keepTemp,
    timeoutMs,
  });

  const favSetup = (teamCombo || [])
    .filter((member) => isFavoniusWeapon(member?.weapon))
    .map((member) => normalizeId(member.character));

  let result = { ...base };

  if (favSetup.length > 0) {
    const favBaseline = buildBaselineGcsl({
      teamCombo,
      rotationGcsl,
      iterations: 1,
      favSetup,
      additionalERByCharacter: {},
    });

    const simulation = await runGcsimConfig({
      gcsimPath,
      configText: favBaseline,
      timeoutMs,
      tempDir,
      keepTemp,
      verbose: false,
    });

    const favContribution = calculateFavoniusEnergyContribution(
      simulation,
      base,
      runtimeBackendPath,
    );

    const orderedCharacters = (teamCombo || []).map((member) =>
      normalizeId(member.character),
    );

    orderedCharacters.forEach((characterId, index) => {
      const characterData = findCharacterData(runtimeBackendPath, characterId);
      const burstCost = Number(characterData?.burstCost || 0);
      const ascensionER = Number(characterData?.ascensionStat?.value || 0);
      const currentAdditional = sanitizeAdditionalER(
        result?.[characterId] || 0,
      );
      result[characterId] = sanitizeAdditionalER(
        calcERAdjustmentForFavonius(
          burstCost,
          ascensionER,
          currentAdditional,
          Number(favContribution[index] || 0),
        ),
      );
    });
  }

  const hasXiphos = (teamCombo || []).some((member) =>
    isXiphosWeapon(member?.weapon),
  );
  if (hasXiphos) {
    result = Object.fromEntries(
      Object.entries(result).map(([key, value]) => [
        key,
        sanitizeAdditionalER(Number(value || 0) - 0.08),
      ]),
    );
  }

  return result;
}
