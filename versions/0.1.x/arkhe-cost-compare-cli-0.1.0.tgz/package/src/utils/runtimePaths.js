import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { resolveFromBase, resolveFromCwd } from "./paths.js";

function getCliRoot() {
  const currentFile = fileURLToPath(import.meta.url);
  return path.resolve(path.dirname(currentFile), "..", "..");
}

export function getVendoredBackendRoot() {
  return path.resolve(getCliRoot(), "vendor", "backend");
}

export function resolveBackendRuntimePath({ strict = true } = {}) {
  const fallbackVendored = getVendoredBackendRoot();

  const modulesPath = path.resolve(fallbackVendored, "modules");
  const dataPath = path.resolve(fallbackVendored, "data");
  if (fs.existsSync(modulesPath) && fs.existsSync(dataPath)) {
    return fallbackVendored;
  }

  if (!strict) {
    return fallbackVendored;
  }

  throw new Error(
    "Could not resolve backend runtime path. Expected vendor/backend with modules and data.",
  );
}

export function resolveGcsimExecutablePath({
  scenarioBaseDir,
  gcsimPath,
  cliOverridePath,
  strict = true,
} = {}) {
  const override = String(cliOverridePath || "").trim();
  const scenarioValue = String(gcsimPath || "").trim();

  const candidates = [];

  if (override) {
    candidates.push(resolveFromCwd(override));
  }

  if (scenarioValue) {
    candidates.push(
      resolveFromBase(scenarioBaseDir || process.cwd(), scenarioValue),
    );
  }

  const base = scenarioBaseDir || process.cwd();
  candidates.push(path.resolve(base, "..", "gcsim", "gcsim.exe"));
  candidates.push(resolveFromCwd("../gcsim/gcsim.exe"));

  const seen = new Set();
  const uniqueCandidates = candidates.filter((entry) => {
    const key = path.resolve(entry);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const existing = uniqueCandidates.find((entry) => fs.existsSync(entry));
  if (existing) return existing;

  if (!strict) {
    return uniqueCandidates[0] || "";
  }

  throw new Error(
    `Could not find gcsim executable. Tried: ${uniqueCandidates.join(", ")}`,
  );
}
