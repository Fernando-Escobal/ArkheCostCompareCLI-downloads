import fs from "fs";
import path from "path";
import { resolveFromBase } from "../utils/paths.js";

function ensureDirForFile(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function escapeCsv(value) {
  const raw = String(value ?? "");
  if (/[",\n]/.test(raw)) {
    return `"${raw.replace(/"/g, '""')}"`;
  }
  return raw;
}

function formatInteger(value) {
  const num = Number(value || 0);
  return String(Math.round(num));
}

export function writeResultsCsv({ rows, rotations, outputPath, baseDir }) {
  const resolvedOutput = resolveFromBase(baseDir, outputPath);
  ensureDirForFile(resolvedOutput);

  const rotationCols = (rotations || []).map(
    (r, idx) =>
      `damage_rot_${String(r.label || r.id || idx + 1)
        .replace(/\s+/g, "_")
        .toLowerCase()}`,
  );

  const headers = [
    "team_tag",
    "Char1ons",
    "char1",
    "char1WeaponRefinement",
    "Char2ons",
    "char2",
    "char2WeaponRefinement",
    "Char3ons",
    "char3",
    "char3WeaponRefinement",
    "Char4ons",
    "char4",
    "char4WeaponRefinement",
    "liquidRolls",
    "cost",
    ...rotationCols,
    "totalDPS",
    "duration",
    "char1AvgPct",
    "char2AvgPct",
    "char3AvgPct",
    "char4AvgPct",
    "char1Set",
    "char1MainStats",
    "char2Set",
    "char2MainStats",
    "char3Set",
    "char3MainStats",
    "char4Set",
    "char4MainStats",
  ];

  const lines = [headers.join(",")];

  rows.forEach((row, idx) => {
    const values = [
      row.team_tag,
      row.char1Cons,
      row.char1,
      row.char1WeaponRefinement,
      row.char2Cons,
      row.char2,
      row.char2WeaponRefinement,
      row.char3Cons,
      row.char3,
      row.char3WeaponRefinement,
      row.char4Cons,
      row.char4,
      row.char4WeaponRefinement,
      row.liquidRolls,
      row.cost,
      ...rotationCols.map((col) => formatInteger(row[col])),
      formatInteger(row.totalDPS),
      Number(row.duration || 0).toFixed(2),
      row.char1AvgPct,
      row.char2AvgPct,
      row.char3AvgPct,
      row.char4AvgPct,
      row.char1Set,
      row.char1MainStats,
      row.char2Set,
      row.char2MainStats,
      row.char3Set,
      row.char3MainStats,
      row.char4Set,
      row.char4MainStats,
    ];
    lines.push(values.map(escapeCsv).join(","));
  });

  fs.writeFileSync(resolvedOutput, `\uFEFF${lines.join("\n")}`, "utf8");
  return resolvedOutput;
}
