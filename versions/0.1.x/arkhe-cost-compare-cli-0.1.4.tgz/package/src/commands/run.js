import { runDryRun } from "./dryRun.js";
import fs from "fs";
import path from "path";
import { resolveFromBase } from "../utils/paths.js";
import { buildGcslConfig } from "../engine/gcslBuilder.js";
import { runGcsimConfig } from "../engine/gcsimAdapter.js";
import { normalizeRotationInput } from "../engine/rotationAdapter.js";
import { computeERForTeam } from "../engine/erAdapter.js";
import { computeUtilVars } from "../engine/utilVarsAdapter.js";
import { writeResultsCsv } from "../output/csvWriter.js";
import { writeResultsJson } from "../output/jsonWriter.js";
import { mapWithConcurrency } from "../utils/parallel.js";
import { buildEnergySignature } from "../utils/energy.js";
import { buildRowTasks } from "../domain/taskPlanner.js";
import {
  resolveBackendRuntimePath,
  resolveGcsimExecutablePath,
  ensureExecutable,
} from "../utils/runtimePaths.js";

function toWeaponRefinementText(weaponRaw) {
  const raw = String(weaponRaw || "").toLowerCase();
  const refineMatch = raw.match(/^r(\d+)/i);
  const refine = refineMatch ? `R${refineMatch[1]}` : "R1";
  const name = raw.replace(/^r\d+/i, "");
  return `${name} ${refine}`.trim();
}

function computeCost(teamCombo) {
  return teamCombo.reduce((sum, member) => {
    return (
      sum +
      (member.isFiveStarWeapon ? 1 : 0) +
      (Number(member.cons || 0) > 0 ? Number(member.cons || 0) : 0)
    );
  }, 0);
}

function buildUtilVarsSignature(teamCombo) {
  return (teamCombo || [])
    .map((member) => {
      return [member.character, member.set]
        .map((value) =>
          String(value || "")
            .trim()
            .toLowerCase(),
        )
        .join(":");
    })
    .join("|");
}

function isFavoniusWeapon(weaponId) {
  const weapon = String(weaponId || "")
    .toLowerCase()
    .replace(/^r\d+/i, "");
  return weapon.includes("fav") && !weapon.includes("aquila");
}

function buildFavMaskBySlot(teamCombo) {
  const parts = [];
  for (let index = 0; index < (teamCombo || []).length; index += 1) {
    if (isFavoniusWeapon(teamCombo[index]?.weapon)) {
      parts.push(`slot${index + 1}`);
    }
  }
  return parts.length > 0 ? parts.join("|") : "none";
}

function buildResultRow({ teamCombo, liquidRolls, aggregate, rotations }) {
  const members = teamCombo;
  const avgShares = aggregate.shareSums.map((value) => {
    return aggregate.shareCount > 0 ? (value / aggregate.shareCount) * 100 : 0;
  });

  const row = {
    char1: members[0]?.character || "-",
    char1Cons: `C${Number(members[0]?.cons || 0)}`,
    char1WeaponRefinement: toWeaponRefinementText(members[0]?.weapon),
    char2: members[1]?.character || "-",
    char2Cons: `C${Number(members[1]?.cons || 0)}`,
    char2WeaponRefinement: toWeaponRefinementText(members[1]?.weapon),
    char3: members[2]?.character || "-",
    char3Cons: `C${Number(members[2]?.cons || 0)}`,
    char3WeaponRefinement: toWeaponRefinementText(members[2]?.weapon),
    char4: members[3]?.character || "-",
    char4Cons: `C${Number(members[3]?.cons || 0)}`,
    char4WeaponRefinement: toWeaponRefinementText(members[3]?.weapon),
    cost: computeCost(members),
    liquidRolls,
    char1AvgPct: `${avgShares[0].toFixed(2)}%`,
    char2AvgPct: `${avgShares[1].toFixed(2)}%`,
    char3AvgPct: `${avgShares[2].toFixed(2)}%`,
    char4AvgPct: `${avgShares[3].toFixed(2)}%`,
    totalDPS: aggregate.weightedDps,
    duration: aggregate.averageDuration,
  };

  rotations.forEach((rotation, idx) => {
    const key = `damage_rot_${String(rotation.label || rotation.id || idx + 1)
      .replace(/\s+/g, "_")
      .toLowerCase()}`;
    row[key] = Number(aggregate.damageByRotation?.[rotation.id] || 0);
  });

  return row;
}

function sortRows(rows, sortBy = "weightedDps", sortDir = "desc") {
  const factor = String(sortDir || "desc").toLowerCase() === "asc" ? 1 : -1;
  const keyMap = {
    weighteddps: "totalDPS",
    totaldps: "totalDPS",
    cost: "cost",
    duration: "duration",
  };

  const resolvedKey =
    keyMap[String(sortBy || "weightedDps").toLowerCase()] || "totalDPS";

  return [...rows].sort((a, b) => {
    const av = Number(a?.[resolvedKey] || 0);
    const bv = Number(b?.[resolvedKey] || 0);
    if (av === bv) return 0;
    return av > bv ? factor : -factor;
  });
}

export async function runScenario(options = {}) {
  const result = await runDryRun(options);
  const { scenario, expanded, scenarioPath } = result;
  const baseDir = path.dirname(scenarioPath);

  const maxRuns = Number(options.maxRuns || 0);
  const totalRuns = expanded.counts.totalRuns;
  const runLimit =
    Number.isFinite(maxRuns) && maxRuns > 0 ? maxRuns : totalRuns;

  const gcsimPath = resolveGcsimExecutablePath({
    scenarioBaseDir: baseDir,
    gcsimPath: scenario.simulation.gcsimPath,
    cliOverridePath: options.gcsimPath,
  });
  ensureExecutable(gcsimPath);
  const backendRuntimePath = resolveBackendRuntimePath();
  const tempDir = resolveFromBase(baseDir, scenario.output.tempDir);
  const erDebugEnabled =
    scenario.simulation.erDebug ||
    ["1", "true", "yes"].includes(
      String(process.env.ARKHE_ER_DEBUG || "")
        .trim()
        .toLowerCase(),
    );
  const erDebugPath = resolveFromBase(
    baseDir,
    process.env.ARKHE_ER_DEBUG_FILE ||
      scenario.simulation.erDebugFile ||
      "./out/er-debug.jsonl",
  );

  if (erDebugEnabled) {
    console.log(`[run] ER debug enabled. log file: ${erDebugPath}`);
  }

  const normalizedRotations = [];
  for (const rotation of scenario.rotations) {
    const gcslRotation = await normalizeRotationInput({
      rotationInput: rotation.input,
      rots: scenario.simulation.rots,
      operation: "calc",
      backendRuntimePath,
      scenarioBaseDir: baseDir,
      verbose: scenario.simulation.gcsimVerbose,
    });
    if (!gcslRotation) {
      throw new Error(
        `Failed to normalize rotation ${rotation.label || rotation.id}`,
      );
    }
    normalizedRotations.push({
      ...rotation,
      gcslRotation,
    });
  }

  const failures = [];
  const erCache = new Map();
  const utilVarsCache = new Map();

  const combinations = expanded.teamCombinations;
  const parallel = Math.max(1, Number(scenario.simulation.parallel || 1));
  const { tasks, scheduledRuns } = buildRowTasks({
    teamCombinations: combinations,
    liquidRolls: scenario.selection.liquidRolls,
    rotations: normalizedRotations,
    runLimit,
  });

  console.log(
    `[run] executing up to ${scheduledRuns} runs (of ${totalRuns} planned) with concurrency ${parallel}.`,
  );

  if (scenario.simulation.enableER) {
    const precomputeJobs = [];
    const seenErCases = new Set();

    for (const teamCombo of combinations) {
      const energySignature = buildEnergySignature(teamCombo);
      const favMask = buildFavMaskBySlot(teamCombo);

      for (const rotation of normalizedRotations) {
        const erCacheKey = `${rotation.id}|energy:${energySignature}`;
        if (seenErCases.has(erCacheKey)) continue;
        seenErCases.add(erCacheKey);

        precomputeJobs.push({
          erCacheKey,
          rotation,
          teamCombo,
          energySignature,
          favMask,
        });
      }
    }

    console.log(
      `[run] ER precompute: ${precomputeJobs.length} unique cases across ${normalizedRotations.length} rotations.`,
    );

    const erCaseSummary = {};
    await mapWithConcurrency(precomputeJobs, parallel, async (job) => {
      const erMap = await computeERForTeam({
        gcsimPath,
        teamCombo: job.teamCombo,
        rotationGcsl: job.rotation.gcslRotation,
        backendRuntimePath,
        scenarioBaseDir: baseDir,
        erIterations: scenario.simulation.erIterations,
        erPercentile: scenario.simulation.erPercentile,
        tempDir,
        keepTemp: scenario.output.keepTemp,
        timeoutMs: scenario.simulation.timeoutMs,
        debug: {
          enabled: erDebugEnabled,
          filePath: erDebugPath,
          scenarioName: scenario.meta.name,
          rotationId: job.rotation.id,
          rotationLabel: job.rotation.label,
          energySignature: job.energySignature,
          teamCombo: job.teamCombo,
          favMask: job.favMask,
          mode: "precompute",
        },
      });

      erCache.set(job.erCacheKey, erMap || {});

      if (!erCaseSummary[job.rotation.id]) {
        erCaseSummary[job.rotation.id] = {
          label: job.rotation.label,
          totalCases: 0,
          favCases: {},
        };
      }
      erCaseSummary[job.rotation.id].totalCases += 1;
      erCaseSummary[job.rotation.id].favCases[job.favMask] =
        (erCaseSummary[job.rotation.id].favCases[job.favMask] || 0) + 1;
    });

    console.log("[run] ER precompute completed.");

    if (erDebugEnabled) {
      try {
        const mapOutputPath = erDebugPath.replace(/\.jsonl$/i, "-map.json");
        fs.writeFileSync(
          mapOutputPath,
          JSON.stringify(
            {
              scenario: scenario.meta,
              erIterations: scenario.simulation.erIterations,
              erPercentile: scenario.simulation.erPercentile,
              totalCases: precomputeJobs.length,
              rotations: erCaseSummary,
            },
            null,
            2,
          ),
          "utf8",
        );
        console.log(`[run] ER case map: ${mapOutputPath}`);
      } catch (err) {
        console.warn(`[run] failed to write ER case map: ${err.message}`);
      }
    }
  }

  let progressCompleted = 0;

  const taskResults = await mapWithConcurrency(
    tasks,
    parallel,
    async (task) => {
      const { teamCombo, liquidRolls, rotations } = task;
      const aggregate = {
        damageByRotation: {},
        weightedDps: 0,
        durationSum: 0,
        durationCount: 0,
        shareSums: [0, 0, 0, 0],
        shareCount: 0,
        averageDuration: 0,
      };

      let hasSuccess = false;
      const energySignature = buildEnergySignature(teamCombo);
      const utilVarsSignature = buildUtilVarsSignature(teamCombo);

      for (const rotation of rotations) {
        try {
          const erCacheKey = `${rotation.id}|energy:${energySignature}`;
          const utilVarsCacheKey = `${rotation.id}|util:${utilVarsSignature}`;
          let additionalERByCharacter = {};
          let utilVars = {
            scrollActivations: 0,
            cryoRes: 0,
            rotationDurationSeconds: 0,
          };

          if (!utilVarsCache.has(utilVarsCacheKey)) {
            utilVarsCache.set(
              utilVarsCacheKey,
              computeUtilVars({
                gcsimPath,
                backendRuntimePath,
                scenarioBaseDir: baseDir,
                teamCombo,
                rotationGcsl: rotation.gcslRotation,
                tempDir,
                keepTemp: scenario.output.keepTemp,
                timeoutMs: scenario.simulation.timeoutMs,
              }),
            );
          }
          utilVars = (await utilVarsCache.get(utilVarsCacheKey)) || utilVars;

          if (scenario.simulation.enableER) {
            if (!erCache.has(erCacheKey)) {
              erCache.set(
                erCacheKey,
                computeERForTeam({
                  gcsimPath,
                  teamCombo,
                  rotationGcsl: rotation.gcslRotation,
                  backendRuntimePath,
                  scenarioBaseDir: baseDir,
                  erIterations: scenario.simulation.erIterations,
                  erPercentile: scenario.simulation.erPercentile,
                  tempDir,
                  keepTemp: scenario.output.keepTemp,
                  timeoutMs: scenario.simulation.timeoutMs,
                  debug: {
                    enabled: erDebugEnabled,
                    filePath: erDebugPath,
                    scenarioName: scenario.meta.name,
                    rotationId: rotation.id,
                    rotationLabel: rotation.label,
                    energySignature,
                    teamCombo,
                  },
                }),
              );
            }
            additionalERByCharacter = (await erCache.get(erCacheKey)) || {};
          }

          const cfg = await buildGcslConfig({
            teamCombo,
            rotationInput: rotation.gcslRotation,
            iterations: scenario.simulation.iterations,
            additionalERByCharacter,
            liquidRolls,
            backendRuntimePath,
            scenarioBaseDir: baseDir,
            scrollActivationsByCharacter: utilVars.scrollActivations,
            cryoRes: utilVars.cryoRes,
          });

          const metrics = await runGcsimConfig({
            gcsimPath,
            configText: cfg,
            timeoutMs: scenario.simulation.timeoutMs,
            tempDir,
            keepTemp: scenario.output.keepTemp,
            verbose: scenario.simulation.gcsimVerbose,
          });

          hasSuccess = true;
          aggregate.damageByRotation[rotation.id] = metrics.dps;
          aggregate.weightedDps +=
            metrics.dps * (Number(rotation.weightPercent || 0) / 100);
          aggregate.durationSum += Number(
            utilVars.rotationDurationSeconds || metrics.duration || 0,
          );
          aggregate.durationCount += 1;

          const totalCharacter = metrics.characterDps.reduce(
            (sum, value) => sum + Number(value || 0),
            0,
          );
          if (totalCharacter > 0) {
            for (let index = 0; index < 4; index += 1) {
              aggregate.shareSums[index] +=
                Number(metrics.characterDps[index] || 0) / totalCharacter;
            }
            aggregate.shareCount += 1;
          }
        } catch (err) {
          failures.push({
            team: teamCombo
              .map((member) => `${member.character}C${member.cons}`)
              .join(", "),
            liquidRolls,
            rotation: rotation.label,
            error: err.message,
          });
        }

        progressCompleted += 1;
        if (
          progressCompleted % Math.max(1, parallel) === 0 ||
          progressCompleted === scheduledRuns
        ) {
          console.log(`[run] progress: ${progressCompleted}/${scheduledRuns}`);
        }
      }

      if (!hasSuccess) {
        return null;
      }

      aggregate.averageDuration =
        aggregate.durationCount > 0
          ? aggregate.durationSum / aggregate.durationCount
          : 0;

      return buildResultRow({
        teamCombo,
        liquidRolls,
        aggregate,
        rotations: normalizedRotations,
      });
    },
  );

  const rows = taskResults.filter(Boolean);

  const sortedRows = sortRows(
    rows,
    scenario.output.sortBy,
    scenario.output.sortDir,
  );
  const topN = Number(scenario.output.topN || 0);
  const finalRows = topN > 0 ? sortedRows.slice(0, topN) : sortedRows;

  const csvPath = writeResultsCsv({
    rows: finalRows,
    rotations: normalizedRotations,
    outputPath: scenario.output.csvPath,
    baseDir,
  });

  const jsonPath = writeResultsJson({
    payload: {
      meta: scenario.meta,
      executedRuns: scheduledRuns,
      plannedRuns: totalRuns,
      concurrency: parallel,
      normalizedRotations,
      rows: finalRows,
      failures,
    },
    outputPath: scenario.output.jsonPath,
    baseDir,
  });

  console.log(`[run] completed. executed runs: ${scheduledRuns}/${totalRuns}`);
  console.log(`[run] rows exported: ${finalRows.length}`);
  console.log(`[run] csv: ${csvPath}`);
  if (jsonPath) {
    console.log(`[run] json: ${jsonPath}`);
  }
  if (failures.length > 0) {
    console.log(
      `[run] failures: ${failures.length} (see json output for details)`,
    );
  }
}
