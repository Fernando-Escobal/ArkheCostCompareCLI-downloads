export function validateScenario(scenario) {
  const errors = [];

  if (!scenario || typeof scenario !== "object") {
    return ["Scenario is empty or invalid"];
  }

  if (!Array.isArray(scenario.rotations) || scenario.rotations.length === 0) {
    errors.push("At least one rotation is required");
  }

  if (Array.isArray(scenario.rotations)) {
    scenario.rotations.forEach((rotation) => {
      if (!String(rotation.input || "").trim()) {
        errors.push(`Rotation ${rotation.id || "?"} has empty input`);
      }
      const weight = Number(rotation.weightPercent);
      if (!Number.isFinite(weight) || weight < 0) {
        errors.push(`Rotation ${rotation.id || "?"} has invalid weight`);
      }
    });
  }

  if (!Array.isArray(scenario.team) || scenario.team.length !== 4) {
    errors.push("Team must contain exactly 4 slots (slot1..slot4)");
  }

  if (Array.isArray(scenario.team)) {
    scenario.team.forEach((member, idx) => {
      const slot = idx + 1;
      if (!String(member.character || "").trim()) {
        errors.push(`slot${slot}.character is required`);
      }
      if (!String(member.weapon4 || "").trim()) {
        errors.push(`slot${slot}.weapon4 is required`);
      }
      if (!String(member.set || "").trim()) {
        errors.push(`slot${slot}.set is required`);
      }
      if (!String(member.main || "").trim()) {
        errors.push(`slot${slot}.main is required`);
      }
      if (
        !Array.isArray(member.consOptions) ||
        member.consOptions.length === 0
      ) {
        errors.push(`slot${slot}.cons must contain at least one option`);
      } else {
        member.consOptions.forEach((cons) => {
          if (!Number.isInteger(cons) || cons < 0 || cons > 6) {
            errors.push(
              `slot${slot}.cons contains invalid value ${cons} (0..6)`,
            );
          }
        });
      }
    });
  }

  if (
    !Array.isArray(scenario.selection?.liquidRolls) ||
    scenario.selection.liquidRolls.length === 0
  ) {
    errors.push("selection.liquidRolls must contain at least one value");
  } else {
    scenario.selection.liquidRolls.forEach((lr) => {
      if (!Number.isInteger(lr) || lr < 1 || lr > 60) {
        errors.push(
          `selection.liquidRolls contains invalid value ${lr} (1..60)`,
        );
      }
    });
  }

  const totalWeight = (scenario.rotations || []).reduce(
    (sum, r) => sum + Number(r.weightPercent || 0),
    0,
  );

  if (
    scenario.selection?.requireWeight100 &&
    Math.abs(totalWeight - 100) > 0.001
  ) {
    errors.push(`Rotation weights must sum 100 (current: ${totalWeight})`);
  }

  if (!String(scenario.output?.csvPath || "").trim()) {
    errors.push("output.csv is required");
  }

  return errors;
}
