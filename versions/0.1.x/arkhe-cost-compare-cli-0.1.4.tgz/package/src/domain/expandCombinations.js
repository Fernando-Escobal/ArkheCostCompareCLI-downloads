function cartesianProduct(arrays) {
  if (!arrays.length) return [[]];
  return arrays.reduce(
    (acc, curr) => acc.flatMap((prev) => curr.map((item) => [...prev, item])),
    [[]],
  );
}

export function expandCombinations(scenario) {
  const team = scenario.team || [];
  const liquidRolls = scenario.selection?.liquidRolls || [];
  const rotations = scenario.rotations || [];

  const consArrays = team.map((member) => member.consOptions || [0]);
  const consCombos = cartesianProduct(consArrays);

  const weaponArrays = team.map((member) => {
    const options = [{ weapon: member.weapon4, isFiveStar: false }];
    if (String(member.weapon5 || "").trim()) {
      options.push({ weapon: member.weapon5, isFiveStar: true });
    }
    return options;
  });
  const weaponCombos = cartesianProduct(weaponArrays);

  const teamCombinations = [];

  consCombos.forEach((consCombo) => {
    weaponCombos.forEach((weaponCombo) => {
      const members = team.map((member, idx) => ({
        slot: member.slot,
        character: member.character,
        cons: consCombo[idx],
        weapon: weaponCombo[idx].weapon,
        set: member.set,
        main: member.main,
        isFiveStarWeapon: weaponCombo[idx].isFiveStar,
      }));
      teamCombinations.push(members);
    });
  });

  return {
    teamCombinations,
    counts: {
      constellationCombinations: consCombos.length,
      weaponCombinations: weaponCombos.length,
      teamCombinations: teamCombinations.length,
      liquidRollVariants: liquidRolls.length,
      rotationCount: rotations.length,
      totalRuns:
        teamCombinations.length * liquidRolls.length * rotations.length,
    },
  };
}
