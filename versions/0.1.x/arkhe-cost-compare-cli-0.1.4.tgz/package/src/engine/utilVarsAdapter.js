import fs from "fs";
import path from "path";
import { runGcsimConfig } from "./gcsimAdapter.js";
import { resolveBackendRuntimePath } from "../utils/runtimePaths.js";

let charactersCache = null;

function normalizeId(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function loadCharactersData(backendRuntimePath) {
  if (charactersCache) return charactersCache;
  const filePath = path.resolve(backendRuntimePath, "data", "characters.json");
  const raw = fs.readFileSync(filePath, "utf8");
  charactersCache = JSON.parse(raw);
  return charactersCache;
}

function buildUtilVarsBaselineGcsl(teamCombo, rotationGcsl, scrollUsers = []) {
  const lines = [];
  const firstCharacter = normalizeId(teamCombo?.[0]?.character);
  const scrollSet = new Set(
    (scrollUsers || []).map((entry) => normalizeId(entry)),
  );

  for (const member of teamCombo || []) {
    const name = normalizeId(member?.character);
    if (!name) continue;
    lines.push(`${name} char lvl=90/90 cons=0 talent=9,9,9;`);
    lines.push(`${name} add weapon="dullblade" refine=5 lvl=90/90;`);
    if (scrollSet.has(name)) {
      lines.push(`${name} add set="scroll" count=4;`);
    }
    lines.push(
      `${name} add stats hp=4780 atk=311 atk%=0.466 hp%=0.466 cr=1 er=1;`,
    );
    lines.push("");
  }

  if (firstCharacter) {
    lines.push(`active ${firstCharacter};`);
    lines.push("");
  }

  lines.push("# Options");
  lines.push("options swap_delay=12 iteration=1 ignore_burst_energy=true;");
  lines.push("target lvl=100 resist=0.1 radius=2 pos=0,2.5 hp=999999999;");
  lines.push("energy every interval=480,720 amount=1;");
  lines.push("");
  lines.push("# Rotation");
  lines.push(String(rotationGcsl || "").trim());
  return lines.join("\n");
}

function extractRepresentativeScrollActivations(rawSimulation, representative) {
  const chars = Array.isArray(rawSimulation?.characters)
    ? rawSimulation.characters
    : [];
  const repChar = chars.find(
    (entry) => normalizeId(entry?.name) === normalizeId(representative),
  );
  if (!repChar) return 0;
  const events = Array.isArray(repChar?.energy_events)
    ? repChar.energy_events
    : [];
  const scrollEvents = events.filter(
    (evt) =>
      evt &&
      typeof evt.source === "string" &&
      evt.source.toLowerCase().includes("scroll-2pc"),
  );
  return scrollEvents.length > 0 ? Math.floor(scrollEvents.length / 4) : 0;
}

function extractDurationSeconds(rawSimulation, metricsDuration) {
  const statsDuration = Number(rawSimulation?.statistics?.duration?.mean);
  if (Number.isFinite(statsDuration) && statsDuration > 0) return statsDuration;
  if (Number.isFinite(Number(metricsDuration)) && Number(metricsDuration) > 0) {
    return Number(metricsDuration);
  }
  const rawDuration = Number(rawSimulation?.duration);
  if (Number.isFinite(rawDuration) && rawDuration > 0) {
    return rawDuration / 60 / 4;
  }
  return 0;
}

function extractCryoRes(rawSimulation, backendRuntimePath, teamCombo) {
  const characters = loadCharactersData(backendRuntimePath);
  let cryoCount = 0;
  for (const member of teamCombo || []) {
    const characterId = normalizeId(member?.character);
    const entry = characters.find(
      (row) => normalizeId(row?.character) === characterId,
    );
    if (normalizeId(entry?.element) === "cryo") {
      cryoCount += 1;
    }
  }
  if (cryoCount <= 1) return 0;

  const durationFrames = Number(rawSimulation?.duration || 0);
  if (!Number.isFinite(durationFrames) || durationFrames <= 0) return 0;

  const reactionUptime = rawSimulation?.enemies?.[0]?.reaction_uptime || {};
  const frozen = Number(reactionUptime?.frozen || 0);
  const cryo = Number(reactionUptime?.cryo || 0);
  return Number((0.15 * ((frozen + cryo) / durationFrames)).toFixed(2)) || 0;
}

export async function computeUtilVars({
  gcsimPath,
  backendRuntimePath,
  scenarioBaseDir,
  teamCombo,
  rotationGcsl,
  tempDir,
  keepTemp = false,
  timeoutMs = 120000,
}) {
  const runtimeBackendPath = resolveBackendRuntimePath({
    scenarioBaseDir,
    backendRuntimePath,
  });

  const scrollUsers = (teamCombo || [])
    .filter((member) => normalizeId(member?.set).includes("scroll"))
    .map((member) => normalizeId(member?.character));
  const representative = scrollUsers[0] || "";

  const baseline = buildUtilVarsBaselineGcsl(
    teamCombo,
    rotationGcsl,
    representative ? [representative] : [],
  );

  const simulation = await runGcsimConfig({
    gcsimPath,
    configText: baseline,
    timeoutMs,
    tempDir,
    keepTemp,
    verbose: false,
  });

  const rawSimulation = simulation?.raw || {};
  return {
    scrollActivations: representative
      ? extractRepresentativeScrollActivations(rawSimulation, representative)
      : 0,
    cryoRes: extractCryoRes(rawSimulation, runtimeBackendPath, teamCombo),
    rotationDurationSeconds: extractDurationSeconds(
      rawSimulation,
      simulation?.duration,
    ),
  };
}
